import type { DesignLayer } from "@/lib/designs";
import {
  FIRST_BASELINE,
  dropCapLayout,
  fontSizeOf,
  listedLines,
  measureAt,
  measureSegs,
  scriptPadsOf,
  segShiftOf,
  segSizeOf,
  textLineHeight,
  type ListedLine,
  type RunKind,
  type Seg,
} from "@/lib/text-fit";

/**
 * Word-level placement for one text frame.
 *
 * Justification follows CorelDRAW's two frame alignment modes:
 *  • "Full justify"  — every line is stretched to the frame edges by widening the word
 *    gaps; the last line of each paragraph keeps its natural width.
 *  • "Force justify" — the same, but every line is stretched, including a paragraph's
 *    last line. A line holding a single word gets its letters spread instead.
 * Space is only ever added or tightened between words (never letters, unless a line has
 * but one word), which is what keeps a justified column looking like type, not stretch.
 */

export interface PlacedRun {
  text: string;
  kind: RunKind;
  x: number;
  y: number;
  size: number;
  width: number;
  font?: string;
  fill?: string;
  letterSpacing?: number;
}

/** Underline / strikethrough as typeset rules so a justified gap stays underlined. */
export interface PlacedRule { x: number; width: number; y: number; thickness: number; fill?: string }

export interface PlacedLine { y: number; runs: PlacedRun[]; rules: PlacedRule[] }

export interface TypesetBlock { lines: PlacedLine[]; dropCap: PlacedRun | null }

interface Word { segs: Seg[]; width: number }

/**
 * Splits a row's runs into words, keeping each part's sub/superscript kind, and records how
 * many spaces sit before each word so intentional double spaces survive typesetting.
 */
function wordsOf(layer: DesignLayer, segs: Seg[]): { words: Word[]; spaces: number[] } {
  const words: Word[] = [];
  const spaces: number[] = [];
  let current: Seg[] = [];
  let pending = 0;
  const flush = () => {
    if (!current.length) return;
    words.push({ segs: current, width: measureSegs(layer, current) });
    spaces.push(pending);
    pending = 0;
    current = [];
  };
  for (const seg of segs) {
    const parts = seg.text.split(" ");
    parts.forEach((part, index) => {
      if (index > 0) { flush(); pending += 1; }
      if (part) current.push({ text: part, kind: seg.kind });
    });
  }
  flush();
  return { words, spaces };
}

const charCount = (words: Word[]) => words.reduce((total, word) => total + word.segs.reduce((n, seg) => n + seg.text.length, 0), 0);

export function typesetText(layer: DesignLayer, maxWidth?: number): TypesetBlock {
  const base = fontSizeOf(layer);
  const rowH = base * textLineHeight(layer);
  const boxWidth = Math.max(1, maxWidth ?? layer.width);
  const align = layer.align || "left";
  const spacing = layer.letterSpacing || 0;
  const wordSpacingScale = Math.max(0.2, Math.min(5, layer.wordSpacing ?? 1));
  const baseSpace = measureAt(layer, " ", segSizeOf(layer, null));
  const space = baseSpace * wordSpacingScale;
  const paraSpacing = layer.paraSpacing || 0;
  const rows: ListedLine[] = listedLines(layer, maxWidth);
  const fixed = layer.autoFit === false;
  const drop = layer.dropCap ? dropCapLayout(layer) : null;
  const underline = !!layer.underline;
  const strike = !!layer.strikethrough;
  // Sub / superscript runs rise and drop beyond the frame edges, so the whole
  // block shifts down by the same headroom the box-height reserves (keeps every
  // glyph inside the selection box, exactly how Word grows the frame).
  const pads = scriptPadsOf(layer);

  let currentY = base * FIRST_BASELINE + pads.top;
  let lastParaIndex = 0;

  const lines: PlacedLine[] = rows.map((row, index) => {
    if (index > 0) {
      currentY += rowH;
      if (row.paraIndex !== lastParaIndex && row.isFirstParaRow) {
        currentY += paraSpacing;
      }
    }
    lastParaIndex = row.paraIndex;
    const y = currentY;

    // listedLines already swallowed the opening letter for the drop cap —
    // stripping it again would eat a real character of the paragraph.
    const segs = row.segs;
    const { words, spaces } = wordsOf(layer, segs);
    const gaps = Math.max(0, words.length - 1);
    const lead = spaces[0] || 0;
    const spaceCount = spaces.reduce((total, count) => total + (count || 0), 0);
    const natural = words.reduce((total, word) => total + word.width, 0) + spaceCount * space;
    const colWidth = Math.max(1, boxWidth - row.indent);
    const extra = colWidth - natural;

    // CorelDRAW: only a fixed frame can justify, and "Full justify" leaves the
    // paragraph's last line — and any single-word line — at its natural width.
    const force = align === "justify-all";
    const justified = fixed && words.length > 0 && (force || (align === "justify" && !row.end && words.length > 1));
    const effectiveSpaceCount = Math.max(1, spaceCount - lead);
    const spread = justified && spaceCount - lead > 0 ? extra / effectiveSpaceCount : 0;
    const gapWidth = gaps > 0 ? Math.max(space * 0.25, space + spread) : 0;
    // A single word fills the line by its letters (CorelDRAW "Force justify").
    const letter = justified && gaps === 0 && extra > 0 ? extra / Math.max(1, charCount(words) - 1) : 0;

    let x = row.indent;
    if (!justified) {
      if (align === "center") x += Math.max(0, (colWidth - natural) / 2);
      else if (align === "right") x += Math.max(0, colWidth - natural);
    }

    const runs: PlacedRun[] = [];
    if (layer.listStyle && layer.listStyle !== "none" && row.marker) {
      runs.push({ text: row.marker, kind: null, x: row.markerX, y, size: segSizeOf(layer, null), width: measureAt(layer, row.marker, segSizeOf(layer, null)), letterSpacing: spacing });
    }
    let cursor = x + lead * space;
    words.forEach((word, index) => {
      if (index > 0) cursor += (spaces[index] || 1) * gapWidth;
      word.segs.forEach(seg => {
        const size = segSizeOf(layer, seg.kind);
        const width = measureAt(layer, seg.text, size) + letter * Math.max(0, seg.text.length - 1);
        runs.push({ text: seg.text, kind: seg.kind, x: cursor, y: y + segShiftOf(layer, seg.kind), size, width, letterSpacing: spacing + letter });
        cursor += width;
      });
    });

    const rules: PlacedRule[] = [];
    if (underline || strike) {
      const groups = new Map<number, PlacedRun[]>();
      for (const run of runs) {
        const key = Math.round(run.y * 100);
        const group = groups.get(key);
        if (group) group.push(run);
        else groups.set(key, [run]);
      }
      for (const group of groups.values()) {
        const left = Math.min(...group.map(run => run.x));
        const right = Math.max(...group.map(run => run.x + run.width));
        const size = group[0].size;
        if (underline) rules.push({ x: left, width: right - left, y: group[0].y + size * 0.12, thickness: Math.max(0.8, size * 0.055) });
        if (strike) rules.push({ x: left, width: right - left, y: group[0].y - size * 0.26, thickness: Math.max(0.8, size * 0.05) });
      }
    }
    return { y, runs, rules };
  });

  let dropCap: PlacedRun | null = null;
  if (drop) {
    dropCap = {
      text: drop.char,
      kind: null,
      x: drop.x,
      y: drop.baseline,
      size: drop.size,
      width: drop.width - drop.gap,
      font: drop.font,
      fill: drop.fill,
      letterSpacing: spacing,
    };
    if (lines.length && (underline || strike)) {
      const rules = lines[0].rules;
      if (underline) rules.push({ x: drop.x, width: drop.width - drop.gap, y: drop.baseline + drop.size * 0.12, thickness: Math.max(0.8, drop.size * 0.055) });
      if (strike) rules.push({ x: drop.x, width: drop.width - drop.gap, y: drop.baseline - drop.size * 0.26, thickness: Math.max(0.8, drop.size * 0.05) });
    }
  }

  return { lines, dropCap };
}
