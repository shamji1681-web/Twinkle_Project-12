import type { DesignDocument } from "@/lib/designs";
import {
  applyStandardPdfFonts, applyVectorPatches, bakeTextDetails, canvasToBlob, MAX_VECTOR_PATCHES,
  planVectorPatches, prepareExportSvg, renderSvgToCanvas,
} from "@/lib/vector-export";
import { loadFontBank, outlineCustomFonts } from "@/lib/text-outlines";

export function readImage(file: File): Promise<string> {
  if (!["image/png", "image/jpeg", "image/webp"].includes(file.type)) return Promise.reject(new Error("Choose a PNG, JPG, or WebP image."));
  if (file.size > 2.8 * 1024 * 1024) return Promise.reject(new Error("Please choose an image smaller than 2.8 MB."));
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error("This image couldn't be read."));
    reader.readAsDataURL(file);
  });
}

function download(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export type ExportFormat = "png" | "jpeg" | "svg" | "pdf";
export interface ExportOptions {
  jpegQuality?: number;
  /** Pixel multiplier for JPG/PNG (1 = design size, 2 = print/retina). */
  rasterScale?: number;
  /** PDF: keep text, shapes, gradients and photos as real vector data. */
  vectorPdf?: boolean;
}

export interface ExportResult { message: string; vectorPatches?: number; patchReasons?: string[] }

const safeName = (title: string) => title.replace(/[^a-z0-9 _-]/gi, "").trim() || "My design";
const clampScale = (value: number | undefined) => Math.max(1, Math.min(4, value ?? 1));

/** Browsers cannot allocate unlimited canvas memory — cap the total pixels. */
function safeScale(doc: DesignDocument, wanted: number): number {
  const max = Math.sqrt(40_000_000 / Math.max(1, doc.width * doc.height));
  return Math.max(1, Math.min(wanted, Math.floor(max * 10) / 10));
}

export async function exportDesign(doc: DesignDocument, title: string, format: ExportFormat, options: ExportOptions = {}): Promise<ExportResult> {
  const prepared = await prepareExportSvg(doc);
  const filename = safeName(title);

  if (format === "svg") {
    // The SVG keeps editable text, vectors and effects and carries its images and
    // uploaded fonts inline, so it opens correctly in any vector tool or browser.
    download(new Blob([prepared.source], { type: "image/svg+xml;charset=utf-8" }), `${filename}.svg`);
    return { message: "Your SVG is downloaded — fully editable vector artwork." };
  }

  if (format === "pdf") {
    const outcome = await exportPdf(prepared, doc, filename, options);
    const fontHint = outcome.reasons.includes("custom font")
      ? " Tip: re-upload that font as TTF, OTF or WOFF to keep its letterforms in the PDF."
      : "";
    return {
      message: outcome.vector
        ? `Your vector PDF is downloaded — selectable text and sharp shapes${outcome.patches ? ` with ${outcome.patches} high-resolution effect layer${outcome.patches > 1 ? "s" : ""}` : ""}.${fontHint}`
        : "Your PDF is downloaded as one high-resolution page image — everything matches the canvas exactly.",
      vectorPatches: outcome.patches,
      patchReasons: outcome.reasons,
    };
  }

  const scale = safeScale(doc, clampScale(options.rasterScale));
  if (format === "jpeg") {
    // JPEG has no alpha: it is flattened over a white page while rendering.
    const canvas = await renderSvgToCanvas(prepared.source, doc.width, doc.height, scale, "#ffffff");
    const quality = Math.max(0.1, Math.min(1, options.jpegQuality ?? 0.92));
    download(await canvasToBlob(canvas, "image/jpeg", quality), `${filename}.jpg`);
    return { message: `Your JPEG is downloaded${scale > 1 ? ` at ${scale}× size` : ""}.` };
  }
  const canvas = await renderSvgToCanvas(prepared.source, doc.width, doc.height, scale);
  download(await canvasToBlob(canvas, "image/png"), `${filename}.png`);
  return { message: `Your transparent PNG is downloaded${scale > 1 ? ` at ${scale}× size` : ""}.` };
}

interface PdfOutcome { vector: boolean; patches: number; reasons: string[] }

async function exportPdf(prepared: Awaited<ReturnType<typeof prepareExportSvg>>, doc: DesignDocument, filename: string, options: ExportOptions): Promise<PdfOutcome> {
  const { jsPDF } = await import("jspdf");
  await import("svg2pdf.js");
  const createPdf = () => new jsPDF({
    orientation: doc.width >= doc.height ? "landscape" : "portrait",
    unit: "pt",
    format: [doc.width, doc.height],
    compress: true,
    putOnlyUsedFonts: true,
  });

  if (options.vectorPdf !== false) {
    const pdf = createPdf();
    try {
      const vector = prepared.svg.cloneNode(true) as SVGSVGElement;
      applyStandardPdfFonts(vector);
      const bakeFailures = bakeTextDetails(vector);
      // Uploaded fonts become glyph outlines: no font file is embedded, so desktop
      // importers (CorelDRAW, Illustrator) never choke on the font dictionaries.
      const bank = await loadFontBank(prepared.families);
      outlineCustomFonts(vector, bank);
      const patches = planVectorPatches(vector, bakeFailures);
      if (patches.length <= MAX_VECTOR_PATCHES) {
        const report = await applyVectorPatches({ original: prepared.original, clean: prepared.svg, target: vector, doc, patches });
        await pdf.svg(vector, { x: 0, y: 0, width: doc.width, height: doc.height });
        pdf.save(`${filename}.pdf`);
        return { vector: true, patches: report.count, reasons: report.reasons };
      }
    } catch (error) {
      console.warn("Vector PDF fallback:", error);
    }
  }

  // Safety net: an exact, lossless page image so the download never fails.
  const pdf = createPdf();
  const scale = safeScale(doc, clampScale(Math.max(options.rasterScale ?? 1, 1.5)));
  const canvas = await renderSvgToCanvas(prepared.source, doc.width, doc.height, scale);
  pdf.addImage(canvas.toDataURL("image/png"), "PNG", 0, 0, doc.width, doc.height, undefined, "FAST");
  pdf.save(`${filename}.pdf`);
  return { vector: false, patches: 0, reasons: [] };
}
