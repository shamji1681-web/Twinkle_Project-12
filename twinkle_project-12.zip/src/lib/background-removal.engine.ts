/**
 * Subject-segmentation engine for browser-side background removal.
 *
 * ONNX Runtime is loaded from the CDN (matching @imgly/background-removal 1.7.0's
 * peer: onnxruntime-web 1.21.0) so the single-file build never inlines WASM.
 * The ISNet model is fetched from IMG.LY's public asset host. Photos never leave
 * the browser. If the model cannot load, callers should fall back to a local cutout.
 */
import type { BackgroundRemovalProgress } from "./background-removal.types";

interface Resource {
  size: number;
  mime: string;
  chunks: { name: string; offsets: [number, number] }[];
}

interface OrtTensor {
  data: unknown;
  dispose: () => void;
}

interface OrtSession {
  inputNames: string[];
  outputNames: string[];
  run: (feeds: Record<string, OrtTensor>) => Promise<Record<string, OrtTensor>>;
}

interface OrtModule {
  env: { wasm: { numThreads: number; proxy: boolean; wasmPaths: string } };
  Tensor: new (type: string, data: Float32Array, dims: number[]) => OrtTensor;
  InferenceSession: {
    create: (model: ArrayBuffer, options: Record<string, unknown>) => Promise<OrtSession>;
  };
}

const ASSET_BASE = "https://staticimgly.com/@imgly/background-removal-data/1.7.0/dist/";
const ORT_VERSION = "1.21.0";
// Tried in order, so a blocked or slow CDN does not break background removal.
const ORT_CDNS = [
  `https://cdn.jsdelivr.net/npm/onnxruntime-web@${ORT_VERSION}/dist/`,
  `https://unpkg.com/onnxruntime-web@${ORT_VERSION}/dist/`,
];
let ortBase = ORT_CDNS[0];
const MODEL_KEY = "/models/isnet_quint8";
const RESOLUTION = 1024;

let runtime: Promise<OrtModule> | null = null;
let session: OrtSession | null = null;
let sessionBuilding: Promise<OrtSession> | null = null;

function asOrt(): OrtModule | undefined {
  return (globalThis as unknown as { ort?: OrtModule }).ort;
}

function loadScript(base: string): Promise<OrtModule> {
  return new Promise<OrtModule>((resolve, reject) => {
    const script = document.createElement("script");
    script.src = `${base}ort.min.js`;
    script.async = true;
    script.crossOrigin = "anonymous";
    script.onload = () => {
      const ort = asOrt();
      if (!ort) { script.remove(); reject(new Error("AI engine did not initialize.")); }
      else { ortBase = base; resolve(ort); }
    };
    script.onerror = () => { script.remove(); reject(new Error("AI engine script failed to load.")); };
    document.head.appendChild(script);
  });
}

function loadRuntime(): Promise<OrtModule> {
  if (runtime) return runtime;
  runtime = (async () => {
    const existing = asOrt();
    if (existing) return existing;
    for (const base of ORT_CDNS) {
      try { return await loadScript(base); } catch { /* try the next CDN */ }
    }
    throw new Error("The AI model could not load. Check your connection and retry.");
  })().catch(error => { runtime = null; throw error; });
  return runtime;
}

async function loadResource(resources: Record<string, Resource>, key: string, onProgress: (progress: BackgroundRemovalProgress) => void): Promise<ArrayBuffer> {
  const resource = resources[key];
  if (!resource?.chunks.length) throw new Error(`Model resource missing: ${key}`);
  let downloaded = 0;
  const chunks = await Promise.all(resource.chunks.map(async chunk => {
    const response = await fetch(new URL(chunk.name, ASSET_BASE), { cache: "force-cache" });
    if (!response.ok) throw new Error(`Model download failed: ${response.status}`);
    const blob = await response.blob();
    if (blob.size !== chunk.offsets[1] - chunk.offsets[0]) throw new Error("Incomplete AI model download.");
    downloaded += blob.size;
    onProgress({ stage: "loading", message: "Downloading AI model", percent: Math.round(downloaded / resource.size * 100) });
    return blob;
  }));
  const blob = new Blob(chunks, { type: resource.mime || "application/octet-stream" });
  if (blob.size !== resource.size) throw new Error("Incomplete AI resource.");
  return blob.arrayBuffer();
}

async function initialize(onProgress: (progress: BackgroundRemovalProgress) => void): Promise<OrtSession> {
  const ort = await loadRuntime();
  const response = await fetch(new URL("resources.json", ASSET_BASE), { cache: "force-cache" });
  if (!response.ok) throw new Error("Could not download AI resource manifest.");
  const resources: Record<string, Resource> = await response.json();
  const model = await loadResource(resources, MODEL_KEY, onProgress);
  ort.env.wasm.numThreads = 1;
  ort.env.wasm.proxy = false;
  ort.env.wasm.wasmPaths = ortBase;
  onProgress({ stage: "loading", message: "Starting subject detection" });
  return ort.InferenceSession.create(model, {
    executionProviders: ["wasm"],
    graphOptimizationLevel: "all",
  });
}

async function getSession(onProgress: (progress: BackgroundRemovalProgress) => void): Promise<OrtSession> {
  if (session) return session;
  if (!sessionBuilding) {
    sessionBuilding = initialize(onProgress).then(ready => {
      session = ready;
      sessionBuilding = null;
      return ready;
    }).catch(error => {
      sessionBuilding = null;
      throw error;
    });
  }
  return sessionBuilding;
}

/** ISNet expects 1024×1024 RGB in NCHW, normalized as pixel/255 − 0.5. */
function inputTensor(ort: OrtModule, pixels: Uint8Array, width: number, height: number): OrtTensor {
  const plane = RESOLUTION * RESOLUTION;
  const input = new Float32Array(plane * 3);
  for (let y = 0; y < RESOLUTION; y++) {
    const sy = Math.min(height - 1, y * height / RESOLUTION);
    const y0 = Math.floor(sy), y1 = Math.min(height - 1, y0 + 1), dy = sy - y0;
    for (let x = 0; x < RESOLUTION; x++) {
      const sx = Math.min(width - 1, x * width / RESOLUTION);
      const x0 = Math.floor(sx), x1 = Math.min(width - 1, x0 + 1), dx = sx - x0;
      for (let channel = 0; channel < 3; channel++) {
        const top = pixels[(y0 * width + x0) * 4 + channel] * (1 - dx) + pixels[(y0 * width + x1) * 4 + channel] * dx;
        const bottom = pixels[(y1 * width + x0) * 4 + channel] * (1 - dx) + pixels[(y1 * width + x1) * 4 + channel] * dx;
        input[channel * plane + y * RESOLUTION + x] = (top * (1 - dy) + bottom * dy) / 255 - 0.5;
      }
    }
  }
  return new ort.Tensor("float32", input, [1, 3, RESOLUTION, RESOLUTION]);
}

function toFloatMask(data: unknown): Float32Array | null {
  if (data instanceof Float32Array) return data;
  if (ArrayBuffer.isView(data)) return new Float32Array(data as unknown as ArrayLike<number>);
  if (Array.isArray(data)) return Float32Array.from(data as number[]);
  return null;
}

/** Runs subject segmentation and returns a per-pixel alpha mask (0–255), same size as the source. */
export async function segmentSubject(pixels: Uint8Array, width: number, height: number, onProgress: (progress: BackgroundRemovalProgress) => void): Promise<Uint8Array> {
  if (!width || !height || width > 2048 || height > 2048) throw new Error("Invalid image dimensions.");
  if (pixels.length !== width * height * 4) throw new Error("Invalid image pixels.");
  const ort = await loadRuntime();
  const engine = await getSession(onProgress);
  onProgress({ stage: "segmenting", message: "Detecting the subject" });
  const input = inputTensor(ort, pixels, width, height);

  let outputs: Record<string, OrtTensor> | undefined;
  try {
    const result = await engine.run({ [engine.inputNames[0]]: input });
    outputs = result;
    const output = result[engine.outputNames[0]];
    const mask = toFloatMask(output.data);
    if (!mask || mask.length < RESOLUTION * RESOLUTION) throw new Error("Invalid AI mask.");
    onProgress({ stage: "refining", message: "Refining subject edges" });
    const alpha = new Uint8Array(width * height);
    for (let y = 0; y < height; y++) {
      const sy = Math.min(RESOLUTION - 1, y * RESOLUTION / height);
      const y0 = Math.floor(sy), y1 = Math.min(RESOLUTION - 1, y0 + 1), dy = sy - y0;
      for (let x = 0; x < width; x++) {
        const sx = Math.min(RESOLUTION - 1, x * RESOLUTION / width);
        const x0 = Math.floor(sx), x1 = Math.min(RESOLUTION - 1, x0 + 1), dx = sx - x0;
        const top = mask[y0 * RESOLUTION + x0] * (1 - dx) + mask[y0 * RESOLUTION + x1] * dx;
        const bottom = mask[y1 * RESOLUTION + x0] * (1 - dx) + mask[y1 * RESOLUTION + x1] * dx;
        const value = Math.max(0, Math.min(1, top * (1 - dy) + bottom * dy));
        alpha[y * width + x] = Math.round(value * 255);
      }
    }
    return alpha;
  } finally {
    input.dispose();
    if (outputs) for (const output of Object.values(outputs)) output.dispose();
  }
}
