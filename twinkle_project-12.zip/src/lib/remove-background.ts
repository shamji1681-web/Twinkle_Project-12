import { resolveAsset } from "./asset-map";
import { segmentSubject } from "./background-removal.engine";
import type { BackgroundRemovalProgress } from "./background-removal.types";
import type { CutoutCrop } from "./cutout-geometry";

export type { BackgroundRemovalProgress } from "./background-removal.types";

interface RemovalOptions {
  /** Trim the result to the subject's bounds (reported back as `crop`). Default: keep the full frame.
   *  A function decides once the frame size is known. */
  trim?: boolean | ((frameWidth: number, frameHeight: number) => boolean);
  signal?: AbortSignal;
  onProgress?: (progress: BackgroundRemovalProgress) => void;
}

const MAX_SIDE = 2048;
// Kept well under the 4 MB layer limit: the original is stored too (for Restore BG) and browser storage is small.
const MAX_PNG_BYTES = 2_200_000;
let busy = false;

function checkCancelled(signal?: AbortSignal) {
  if (signal?.aborted) throw new DOMException("Background removal cancelled.", "AbortError");
}

function loadImage(src: string, signal?: AbortSignal): Promise<HTMLImageElement> {
  checkCancelled(signal);
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.crossOrigin = "anonymous";
    const cleanup = () => {
      clearTimeout(timer);
      signal?.removeEventListener("abort", abort);
      image.onload = null;
      image.onerror = null;
    };
    const abort = () => {
      cleanup();
      image.src = "";
      reject(new DOMException("Background removal cancelled.", "AbortError"));
    };
    const timer = setTimeout(() => {
      cleanup();
      image.src = "";
      reject(new Error("The photo took too long to load. Try uploading it again."));
    }, 30_000);
    image.onload = () => {
      cleanup();
      if (!image.naturalWidth || !image.naturalHeight) reject(new Error("This image has no readable pixels."));
      else resolve(image);
    };
    image.onerror = () => {
      cleanup();
      reject(new Error("This photo could not be loaded. Try a PNG, JPG or WebP upload."));
    };
    signal?.addEventListener("abort", abort, { once: true });
    image.src = resolveAsset(src);
  });
}

function pngBlob(canvas: HTMLCanvasElement): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error("The transparent PNG could not be created.")), "image/png");
  });
}

async function storablePng(canvas: HTMLCanvasElement, signal?: AbortSignal): Promise<string> {
  let output = await pngBlob(canvas);
  let ratio = 1;
  while (output.size > MAX_PNG_BYTES && ratio > 0.25) {
    checkCancelled(signal);
    ratio *= 0.8;
    const smaller = document.createElement("canvas");
    smaller.width = Math.max(1, Math.round(canvas.width * ratio));
    smaller.height = Math.max(1, Math.round(canvas.height * ratio));
    const context = smaller.getContext("2d");
    if (!context) throw new Error("Canvas is not available in this browser.");
    context.imageSmoothingQuality = "high";
    context.drawImage(canvas, 0, 0, smaller.width, smaller.height);
    output = await pngBlob(smaller);
    smaller.width = smaller.height = 0;
  }
  if (output.size > MAX_PNG_BYTES) throw new Error("The result is too large to save. Try a smaller photo.");
  checkCancelled(signal);
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error("The transparent PNG could not be read."));
    reader.readAsDataURL(output);
  });
}

function rgbToLab(r: number, g: number, b: number): [number, number, number] {
  let R = r / 255, G = g / 255, B = b / 255;
  R = R > 0.04045 ? ((R + 0.055) / 1.055) ** 2.4 : R / 12.92;
  G = G > 0.04045 ? ((G + 0.055) / 1.055) ** 2.4 : G / 12.92;
  B = B > 0.04045 ? ((B + 0.055) / 1.055) ** 2.4 : B / 12.92;
  let x = (R * 0.4124 + G * 0.3576 + B * 0.1805) / 0.95047;
  let y = (R * 0.2126 + G * 0.7152 + B * 0.0722);
  let z = (R * 0.0193 + G * 0.1192 + B * 0.9505) / 1.08883;
  const f = (t: number) => t > 0.008856 ? Math.cbrt(t) : 7.787 * t + 16 / 116;
  x = f(x); y = f(y); z = f(z);
  return [116 * y - 16, 500 * (x - y), 200 * (y - z)];
}

/** Edge-connected flood fill in Lab space, then a 2px feather. Works offline when the AI model cannot load. */
function localCutout(image: ImageData): boolean {
  const w = image.width, h = image.height, px = image.data, n = w * h;
  const L = new Float32Array(n), A = new Float32Array(n), Bb = new Float32Array(n);
  for (let i = 0, p = 0; i < n; i++, p += 4) {
    const lab = rgbToLab(px[p], px[p + 1], px[p + 2]);
    L[i] = lab[0]; A[i] = lab[1]; Bb[i] = lab[2];
  }

  const border: number[] = [];
  for (let x = 0; x < w; x++) { border.push(x); border.push((h - 1) * w + x); }
  for (let y = 1; y < h - 1; y++) { border.push(y * w); border.push(y * w + w - 1); }

  let mL = 0, mA = 0, mB = 0, opaque = 0;
  for (const i of border) {
    if (px[i * 4 + 3] < 12) continue;
    mL += L[i]; mA += A[i]; mB += Bb[i]; opaque++;
  }
  if (opaque < 8) return false;
  mL /= opaque; mA /= opaque; mB /= opaque;

  let variance = 0;
  for (const i of border) {
    if (px[i * 4 + 3] < 12) continue;
    const dL = L[i] - mL, dA = A[i] - mA, dB = Bb[i] - mB;
    variance += dL * dL + dA * dA + dB * dB;
  }
  const std = Math.sqrt(variance / opaque);
  const tGlobal = Math.max(16, Math.min(38, std * 1.85 + 14));
  const tLocal = Math.max(9, Math.min(24, std * 0.95 + 9));
  const g2 = tGlobal * tGlobal, l2 = tLocal * tLocal;

  const bg = new Uint8Array(n);
  const queue = new Int32Array(n);
  let qs = 0, qe = 0;

  const seed = (i: number) => {
    if (bg[i]) return;
    if (px[i * 4 + 3] < 12) { bg[i] = 1; queue[qe++] = i; return; }
    const dL = L[i] - mL, dA = A[i] - mA, dB = Bb[i] - mB;
    if (dL * dL + dA * dA + dB * dB <= g2) { bg[i] = 1; queue[qe++] = i; }
  };
  for (const i of border) seed(i);

  while (qs < qe) {
    const i = queue[qs++];
    const x = i % w, y = (i / w) | 0;
    const neighbors = [x > 0 ? i - 1 : -1, x < w - 1 ? i + 1 : -1, y > 0 ? i - w : -1, y < h - 1 ? i + w : -1];
    for (const j of neighbors) {
      if (j < 0 || bg[j]) continue;
      if (px[j * 4 + 3] < 12) { bg[j] = 1; queue[qe++] = j; continue; }
      const dL = L[j] - L[i], dA = A[j] - A[i], dB = Bb[j] - Bb[i];
      const local = dL * dL + dA * dA + dB * dB;
      const gL = L[j] - mL, gA = A[j] - mA, gB = Bb[j] - mB;
      const global = gL * gL + gA * gA + gB * gB;
      if (local <= l2 && (global <= g2 * 2.6 || local <= l2 * 0.4)) { bg[j] = 1; queue[qe++] = j; }
    }
  }

  let bgCount = 0;
  for (let i = 0; i < n; i++) if (bg[i]) bgCount++;
  if (bgCount < n * 0.015 || bgCount > n * 0.985) return false;

  let alpha = new Uint8Array(n);
  for (let i = 0; i < n; i++) alpha[i] = bg[i] ? 0 : 255;
  for (let pass = 0; pass < 2; pass++) {
    const next = new Uint8Array(n);
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const i = y * w + x;
        if (x === 0 || y === 0 || x === w - 1 || y === h - 1) { next[i] = alpha[i]; continue; }
        next[i] = (alpha[i] * 4 + alpha[i - 1] + alpha[i + 1] + alpha[i - w] + alpha[i + w]) >> 3;
      }
    }
    alpha = next;
  }

  for (let i = 0, p = 3; i < n; i++, p += 4) px[p] = Math.round(px[p] * alpha[i] / 255);
  return true;
}

/** 0/1 mask grown by `radius` pixels (separable sliding-window max). */
function dilate(mask: Uint8Array, w: number, h: number, radius: number): Uint8Array {
  const horizontal = new Uint8Array(w * h);
  for (let y = 0; y < h; y++) {
    const row = y * w;
    let count = 0;
    for (let x = 0; x < Math.min(radius, w); x++) count += mask[row + x];
    for (let x = 0; x < w; x++) {
      if (x + radius < w) count += mask[row + x + radius];
      if (x - radius - 1 >= 0) count -= mask[row + x - radius - 1];
      horizontal[row + x] = count > 0 ? 1 : 0;
    }
  }
  const out = new Uint8Array(w * h);
  const column = new Int32Array(w);
  for (let y = 0; y < Math.min(radius, h); y++) for (let x = 0; x < w; x++) column[x] += horizontal[y * w + x];
  for (let y = 0; y < h; y++) {
    if (y + radius < h) for (let x = 0; x < w; x++) column[x] += horizontal[(y + radius) * w + x];
    if (y - radius - 1 >= 0) for (let x = 0; x < w; x++) column[x] -= horizontal[(y - radius - 1) * w + x];
    for (let x = 0; x < w; x++) out[y * w + x] = column[x] > 0 ? 1 : 0;
  }
  return out;
}

/**
 * Turns the AI's soft probability map into a clean cutout mask:
 *  1. contrast curve – faint "haze" (< ~12 %) becomes fully transparent, solid areas fully opaque,
 *     while the in-between values are kept so hair and edges stay soft;
 *  2. drops small disconnected blobs (ghost specks left in the background), keeping every real subject.
 */
function refineMask(mask: Uint8Array, w: number, h: number): Uint8Array {
  const n = w * h;
  const low = 0.12 * 255, high = 0.92 * 255;
  const curve = new Uint8Array(256);
  for (let v = 0; v < 256; v++) {
    const t = Math.min(1, Math.max(0, (v - low) / (high - low)));
    curve[v] = Math.round(255 * t * t * (3 - 2 * t));
  }
  const out = new Uint8Array(n);
  for (let i = 0; i < n; i++) out[i] = curve[mask[i]];

  // Connected regions of clearly-opaque pixels (8-neighbour flood fill).
  const labels = new Int32Array(n);
  const queue = new Int32Array(n);
  const sizes: number[] = [0];
  for (let start = 0; start < n; start++) {
    if (out[start] < 128 || labels[start]) continue;
    const id = sizes.length;
    let head = 0, tail = 0, size = 0;
    labels[start] = id; queue[tail++] = start;
    while (head < tail) {
      const i = queue[head++]; size++;
      const x = i % w, y = (i / w) | 0;
      for (let dy = -1; dy <= 1; dy++) {
        const ny = y + dy;
        if (ny < 0 || ny >= h) continue;
        for (let dx = -1; dx <= 1; dx++) {
          const nx = x + dx;
          if ((dx === 0 && dy === 0) || nx < 0 || nx >= w) continue;
          const j = ny * w + nx;
          if (out[j] >= 128 && !labels[j]) { labels[j] = id; queue[tail++] = j; }
        }
      }
    }
    sizes.push(size);
  }
  const largest = Math.max(0, ...sizes);
  if (!largest) return out;
  const minimum = Math.max(24, largest * 0.015);
  const keep = new Uint8Array(n);
  for (let i = 0; i < n; i++) if (labels[i] && sizes[labels[i]] >= minimum) keep[i] = 1;
  // Soft edge pixels next to a kept region stay; everything farther away from any kept region is cleared.
  const near = dilate(keep, w, h, Math.max(3, Math.round(Math.max(w, h) * 0.004)));
  for (let i = 0; i < n; i++) if (!near[i]) out[i] = 0;
  return out;
}

/** Smallest box containing every visible pixel (alpha above a small threshold), or null when nothing is visible. */
function visibleBounds(image: ImageData): { x: number; y: number; width: number; height: number } | null {
  const { width, height, data } = image;
  let minX = width, minY = height, maxX = -1, maxY = -1;
  for (let y = 0; y < height; y++) {
    const row = y * width * 4;
    for (let x = 0; x < width; x++) {
      if (data[row + x * 4 + 3] > 12) {
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
    }
  }
  return maxX < 0 ? null : { x: minX, y: minY, width: maxX - minX + 1, height: maxY - minY + 1 };
}

function applyMask(image: ImageData, mask: Uint8Array) {
  const px = image.data;
  let sourceAlpha = 0, keptAlpha = 0;
  for (let i = 0, p = 3; i < mask.length; i++, p += 4) {
    const alpha = px[p];
    sourceAlpha += alpha;
    px[p] = Math.round(alpha * mask[i] / 255);
    keptAlpha += px[p];
  }
  return { sourceAlpha, keptAlpha };
}

function isUsefulCut(sourceAlpha: number, keptAlpha: number) {
  if (keptAlpha < Math.max(255, sourceAlpha * 0.0001)) return false;
  if (sourceAlpha - keptAlpha < sourceAlpha * 0.008) return false;
  return true;
}

export interface CutoutResult {
  dataUrl: string;
  /** Where the trimmed cutout sits inside the full photo, or null when the whole frame was kept. */
  crop: CutoutCrop | null;
  /** Size of the full frame the analysis ran on (same aspect ratio as the source photo). */
  frameWidth: number;
  frameHeight: number;
}

/** Subject segmentation, not colour erasure. Images stay local; only model assets are downloaded. */
export async function removeBackgroundWithBounds(src: string, options: RemovalOptions = {}): Promise<CutoutResult> {
  if (!src) throw new Error("Select a photo first.");
  if (busy) throw new Error("Another background removal is still running. Please wait.");
  checkCancelled(options.signal);
  busy = true;
  let canvas: HTMLCanvasElement | undefined;
  let trimmed: HTMLCanvasElement | undefined;
  try {
    options.onProgress?.({ stage: "preparing", message: "Preparing the photo" });
    const image = await loadImage(src, options.signal);
    checkCancelled(options.signal);
    const ratio = Math.min(1, MAX_SIDE / Math.max(image.naturalWidth, image.naturalHeight));
    canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(image.naturalWidth * ratio));
    canvas.height = Math.max(1, Math.round(image.naturalHeight * ratio));
    const context = canvas.getContext("2d", { willReadFrequently: true });
    if (!context) throw new Error("Canvas is not available in this browser.");
    context.imageSmoothingQuality = "high";
    context.drawImage(image, 0, 0, canvas.width, canvas.height);
    let original: ImageData;
    try { original = context.getImageData(0, 0, canvas.width, canvas.height); }
    catch { throw new Error("This photo blocks pixel access. Upload a local copy, then try Remove BG again."); }

    const flattened = new Uint8Array(original.data.length);
    for (let i = 0; i < flattened.length; i += 4) {
      const a = original.data[i + 3] / 255;
      for (let c = 0; c < 3; c++) flattened[i + c] = Math.round(original.data[i + c] * a + 255 * (1 - a));
      flattened[i + 3] = 255;
    }

    const snapshot = new Uint8ClampedArray(original.data);
    let cut = false;
    if (typeof WebAssembly !== "undefined") {
      try {
        options.onProgress?.({ stage: "loading", message: "Preparing AI (first use downloads the model)" });
        const mask = await segmentSubject(flattened, canvas.width, canvas.height, progress => options.onProgress?.(progress));
        checkCancelled(options.signal);
        if (mask.length === canvas.width * canvas.height) {
          options.onProgress?.({ stage: "refining", message: "Cleaning up the edges" });
          const { sourceAlpha, keptAlpha } = applyMask(original, refineMask(mask, canvas.width, canvas.height));
          cut = isUsefulCut(sourceAlpha, keptAlpha);
        }
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") throw error;
        cut = false;
      }
    }

    if (!cut) {
      checkCancelled(options.signal);
      options.onProgress?.({ stage: "refining", message: "Cutting out the subject" });
      original.data.set(snapshot);
      if (!localCutout(original)) {
        throw new Error("No separate background was detected. Try a photo with a clearer subject, or a more even backdrop.");
      }
    }

    context.putImageData(original, 0, 0);
    options.onProgress?.({ stage: "encoding", message: "Creating transparent PNG" });

    // Trim the empty margin so the layer hugs the subject (skipped when the subject fills the frame anyway).
    let output = canvas;
    let crop: CutoutCrop | null = null;
    const wantTrim = typeof options.trim === "function" ? options.trim(canvas.width, canvas.height) : !!options.trim;
    const bounds = wantTrim ? visibleBounds(original) : null;
    if (bounds) {
      const margin = Math.max(2, Math.round(Math.max(canvas.width, canvas.height) * 0.006));
      const x = Math.max(0, bounds.x - margin), y = Math.max(0, bounds.y - margin);
      const width = Math.min(canvas.width - x, bounds.width + margin * 2), height = Math.min(canvas.height - y, bounds.height + margin * 2);
      if (width * height < canvas.width * canvas.height * 0.9) {
        trimmed = document.createElement("canvas");
        trimmed.width = width; trimmed.height = height;
        const trimmedContext = trimmed.getContext("2d");
        if (!trimmedContext) throw new Error("Canvas is not available in this browser.");
        trimmedContext.drawImage(canvas, x, y, width, height, 0, 0, width, height);
        output = trimmed;
        crop = { x: x / canvas.width, y: y / canvas.height, width: width / canvas.width, height: height / canvas.height };
      }
    }
    const dataUrl = await storablePng(output, options.signal);
    checkCancelled(options.signal);
    return { dataUrl, crop, frameWidth: canvas.width, frameHeight: canvas.height };
  } finally {
    busy = false;
    if (canvas) canvas.width = canvas.height = 0;
    if (trimmed) trimmed.width = trimmed.height = 0;
  }
}

/** Same cutout, but always the full frame (used by the API layer). */
export async function removeBackgroundInBrowser(src: string, options: RemovalOptions = {}): Promise<string> {
  return (await removeBackgroundWithBounds(src, options)).dataUrl;
}
