export interface GradientStop { offset: number; color: string; alpha?: number }
export interface GradientFill { type: "linear" | "radial"; angle: number; stops: GradientStop[]; from?: string; to?: string }

export function gradientStopsOf(g: GradientFill): GradientStop[] {
  if (g.stops && g.stops.length >= 2) return [...g.stops].sort((a, b) => a.offset - b.offset);
  return [{ offset: 0, color: g.from || "#7c4de0", alpha: 1 }, { offset: 1, color: g.to || "#f8cbd7", alpha: 1 }];
}
export function gradientCss(g: GradientFill) {
  const stops = gradientStopsOf(g).map(s => `${hexWithAlpha(s.color, s.alpha ?? 1)} ${Math.round(s.offset * 100)}%`).join(", ");
  return g.type === "radial" ? `radial-gradient(circle, ${stops})` : `linear-gradient(${g.angle}deg, ${stops})`;
}
export function hexWithAlpha(hex: string, alpha: number) {
  if (alpha >= 1 || hex === "transparent") return hex;
  const a = Math.round(Math.max(0, Math.min(1, alpha)) * 255).toString(16).padStart(2, "0");
  const base = hex.length === 4 ? "#" + [...hex.slice(1)].map(c => c + c).join("") : hex.slice(0, 7);
  return base + a;
}
export function isGradientFill(value: unknown): value is GradientFill {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const g = value as GradientFill;
  const color = (v: unknown) => typeof v === "string" && (/^#(?:[0-9a-f]{3}|[0-9a-f]{4}|[0-9a-f]{6}|[0-9a-f]{8})$/i.test(v) || v === "transparent");
  if (!["linear", "radial"].includes(g.type) || !Number.isFinite(g.angle) || Math.abs(g.angle) > 360) return false;
  if (g.stops === undefined) return color(g.from) && color(g.to);
  return Array.isArray(g.stops) && g.stops.length >= 2 && g.stops.length <= 8 && g.stops.every(s => !!s && typeof s === "object" && Number.isFinite(s.offset) && s.offset >= 0 && s.offset <= 1 && color(s.color) && (s.alpha === undefined || (Number.isFinite(s.alpha) && s.alpha >= 0 && s.alpha <= 1)));
}
