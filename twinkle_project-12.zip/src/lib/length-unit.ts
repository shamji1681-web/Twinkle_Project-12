import { useSyncExternalStore } from "react";
import { fromDisplayUnit, toDisplayUnit, type LengthUnit } from "@/lib/table";

/**
 * The measurement unit (MM / Inch / Px) shown for canvas and element sizes.
 * Defaults to "mm" (MM) as requested.
 */
const STORAGE_KEY = "creato-canvas-unit-mm";
export const LENGTH_UNITS: LengthUnit[] = ["mm", "in", "px"];

export const LENGTH_UNIT_LABELS: Record<LengthUnit, string> = {
  mm: "MM",
  in: "Inch",
  px: "Px",
};

export function formatLengthValue(px: number, unit: LengthUnit): string {
  const converted = toDisplayUnit(px, unit);
  if (unit === "px") return String(Math.round(converted));
  return String(Number(converted.toFixed(2)));
}

/**
 * Same conversion, but always padded: MM / Inch keep their two decimals
 * (156.6 shows as "156.60"), so the last digits of a size never look dropped or raised.
 */
export function formatLengthExact(px: number, unit: LengthUnit): string {
  const converted = toDisplayUnit(px, unit);
  if (unit === "px") return String(Math.round(converted));
  return converted.toFixed(2);
}

/** "211.55 w × 156.60 h MM" — the readable one-line canvas / element size. */
export function formatSizeLabel(widthPx: number, heightPx: number, unit: LengthUnit): string {
  return `${formatLengthExact(widthPx, unit)} w × ${formatLengthExact(heightPx, unit)} h ${LENGTH_UNIT_LABELS[unit]}`;
}

export function clampCanvasPx(px: number): number {
  return Math.min(5000, Math.max(64, Math.round(px)));
}

export function inputToCanvasPx(value: number, unit: LengthUnit): number {
  return clampCanvasPx(fromDisplayUnit(value, unit));
}

function readStored(): LengthUnit {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return LENGTH_UNITS.includes(stored as LengthUnit) ? (stored as LengthUnit) : "mm";
  } catch {
    return "mm";
  }
}

let current: LengthUnit = readStored();
const listeners = new Set<() => void>();

export function setLengthUnit(unit: LengthUnit) {
  if (unit === current) return;
  current = unit;
  try { localStorage.setItem(STORAGE_KEY, unit); } catch { /* storage may be unavailable */ }
  listeners.forEach(listener => listener());
}

const subscribe = (listener: () => void) => { listeners.add(listener); return () => { listeners.delete(listener); }; };

export function useLengthUnit(): [LengthUnit, (unit: LengthUnit) => void] {
  const unit = useSyncExternalStore(subscribe, () => current, () => "mm" as LengthUnit);
  return [unit, setLengthUnit];
}
