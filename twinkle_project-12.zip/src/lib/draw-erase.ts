/**
 * Eraser for freehand drawings. The stroke stays a single element: each eraser dab is
 * recorded on the layer (in its local coordinates) and hidden with an SVG mask at render
 * time. When nothing visible remains, the layer is removed entirely.
 */
import type { DesignLayer } from "@/lib/designs";

interface Point { x: number; y: number }

/** Parses the stroke's path (M / L / Q commands) back into layer-local points. */
export function samplePathPoints(d: string): Point[] {
  const points: Point[] = [];
  const regex = /([MLQ])\s*([^MLQ]+)/gi;
  let match: RegExpExecArray | null;
  while ((match = regex.exec(d)) !== null) {
    const type = match[1].toUpperCase();
    const nums = match[2].trim().split(/[\s,]+/).map(Number).filter(n => !isNaN(n));
    if (type === "M" || type === "L") {
      for (let i = 0; i + 1 < nums.length; i += 2) points.push({ x: nums[i], y: nums[i + 1] });
    } else if (type === "Q") {
      for (let i = 0; i + 3 < nums.length; i += 4) {
        points.push({ x: (nums[i] + nums[i + 2]) / 2, y: (nums[i + 1] + nums[i + 3]) / 2 });
        points.push({ x: nums[i + 2], y: nums[i + 3] });
      }
    }
  }
  return points;
}

/** Densely samples the stroke so hit tests are accurate along its whole length. */
function densePoints(d: string): Point[] {
  const raw = samplePathPoints(d);
  if (raw.length < 2) return raw;
  const out: Point[] = [];
  for (let i = 0; i < raw.length - 1; i++) {
    const a = raw[i], b = raw[i + 1];
    const steps = Math.max(1, Math.ceil(Math.hypot(b.x - a.x, b.y - a.y) / 3));
    for (let s = 0; s < steps; s++) { const t = s / steps; out.push({ x: a.x + t * (b.x - a.x), y: a.y + t * (b.y - a.y) }); }
  }
  out.push(raw[raw.length - 1]);
  return out;
}

/**
 * Applies one eraser dab (canvas coordinates) to a draw layer.
 * Returns `null` when the dab misses, `[]` when the whole stroke is now erased,
 * or `[updatedLayer]` with the dab recorded — always the same single element.
 */
export function eraseFromDrawLayer(layer: DesignLayer, eraserPos: Point, eraserRadius: number): DesignLayer[] | null {
  if (layer.type !== "draw" || !layer.d) return null;

  const natW = layer.naturalWidth || layer.width, natH = layer.naturalHeight || layer.height;
  const scaleX = natW / layer.width, scaleY = natH / layer.height;
  const local: Point = { x: (eraserPos.x - layer.x) * scaleX, y: (eraserPos.y - layer.y) * scaleY };
  const radius = eraserRadius * Math.max(scaleX, scaleY);
  const sw = layer.strokeWidth || 6;

  // Cheap bounding-box reject.
  const pad = radius + sw;
  if (local.x < -pad || local.x > natW + pad || local.y < -pad || local.y > natH + pad) return null;

  const pts = densePoints(layer.d);
  if (pts.length < 2) return null;
  const hitDist = radius + sw / 2;
  if (!pts.some(p => Math.hypot(p.x - local.x, p.y - local.y) <= hitDist)) return null;

  const erased: NonNullable<DesignLayer["erased"]> = [...(layer.erased || []), [Math.round(local.x * 10) / 10, Math.round(local.y * 10) / 10, Math.round(radius * 10) / 10]];

  // If every sampled point is now covered by some dab, nothing visible remains.
  const covered = (p: Point) => erased.some(([ex, ey, er]) => Math.hypot(p.x - ex, p.y - ey) <= er + sw / 2);
  if (pts.every(covered)) return [];

  // Merge dabs that are practically identical to keep the list small while dragging.
  const last = erased[erased.length - 2];
  if (last && Math.hypot(last[0] - local.x, last[1] - local.y) < radius * 0.35 && Math.abs(last[2] - radius) < 0.5) erased.splice(erased.length - 1, 1);

  return [{ ...layer, erased }];
}
