import type { DesignLayer } from "@/lib/designs";
import { cellKey, tableCellTextStyle } from "@/lib/table";
import { wrapString } from "@/lib/text-fit";

/** A single layout used by SVG, exports and the in-cell typing overlay. */
export function layoutCellText(layer: DesignLayer, r: number, c: number, width: number, height: number) {
  const style = tableCellTextStyle(layer, r, c);
  const value = layer.cells?.[(layer.cols || 1) * r + c] || "";
  const padX = Math.min(6, width * .12), padY = Math.min(5, height * .12);
  const availableWidth = Math.max(1, width - padX * 2), availableHeight = Math.max(1, height - padY * 2);
  let fontSize = style.fontSize;
  let lines = wrapString(value, availableWidth, { ...style, fontSize });
  // Legacy auto-sized cells keep fitting. An explicitly chosen size must not silently shrink.
  const explicit = layer.cellTextStyles?.[cellKey(r, c)]?.fontSize !== undefined || layer.fontSize !== undefined;
  if (!explicit) {
    for (let i = 0; i < 30 && lines.length * fontSize * style.lineHeight > availableHeight && fontSize > 8; i++) {
      fontSize = Math.max(8, fontSize * .9);
      lines = wrapString(value, availableWidth, { ...style, fontSize });
    }
  }
  const blockHeight = lines.length * fontSize * style.lineHeight;
  const spare = Math.max(0, availableHeight - blockHeight);
  const top = padY + (style.verticalAlign === "bottom" ? spare : style.verticalAlign === "middle" ? spare / 2 : 0);
  return { ...style, fontSize, lines, top, padX, padY, blockHeight, availableWidth, availableHeight };
}
