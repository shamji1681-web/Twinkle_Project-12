/**
 * Built-in centre logos for QR codes, drawn with plain canvas primitives.
 * Canvas drawing avoids SVG fill-rule pitfalls, so the marks look identical in the
 * "Live preview" thumbnail, the picker tiles and the exported QR image.
 * Keys are stored on the design as `brand:<key>`, keeping saved documents small.
 */
export const BRAND_PREFIX = "brand:";

export interface BrandLogo { key: string; name: string; /** Badge background colour. */ color: string; /** Colour used to tint the QR code itself (falls back to the badge colour). */ tint?: string; draw: (ctx: CanvasRenderingContext2D) => void }

const TAU = Math.PI * 2;

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}
function ring(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, w: number) { ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.lineWidth = w; ctx.stroke(); }
function dot(ctx: CanvasRenderingContext2D, x: number, y: number, r: number) { ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); }
/** Fills an SVG path string authored in a `source`-unit viewBox, scaled into the 100×100 logo box. */
function glyph(ctx: CanvasRenderingContext2D, d: string, source: number, color: string, inset = 0) {
  const scale = (100 - inset * 2) / source;
  ctx.save();
  ctx.translate(inset, inset);
  ctx.scale(scale, scale);
  ctx.fillStyle = color;
  try { ctx.fill(new Path2D(d)); } catch { /* Path2D unsupported — logo falls back to its plate colour. */ }
  ctx.restore();
}

function bar(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, angle: number) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(angle); roundRect(ctx, -w / 2, -h / 2, w, h, Math.min(w, h) * 0.28); ctx.fill(); ctx.restore();
}

export const BRAND_LOGOS: BrandLogo[] = [
  {
    key: "web", name: "Link / Web", color: "#3b82f6",
    draw(ctx) {
      ctx.strokeStyle = "#fff"; ring(ctx, 50, 50, 26, 7); ctx.beginPath(); ctx.ellipse(50, 50, 13, 26, 0, 0, TAU); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(24, 50); ctx.lineTo(76, 50); ctx.stroke();
    },
  },
  {
    key: "wifi", name: "Wi‑Fi", color: "#8b5cf6",
    draw(ctx) {
      ctx.strokeStyle = "#fff"; ctx.lineCap = "round";
      ctx.beginPath(); ctx.arc(50, 74, 42, Math.PI * 1.23, Math.PI * 1.77); ctx.lineWidth = 8; ctx.stroke();
      ctx.beginPath(); ctx.arc(50, 74, 28, Math.PI * 1.22, Math.PI * 1.78); ctx.lineWidth = 8; ctx.stroke();
      ctx.beginPath(); ctx.arc(50, 74, 14, Math.PI * 1.16, Math.PI * 1.84); ctx.lineWidth = 8; ctx.stroke();
      ctx.fillStyle = "#fff"; dot(ctx, 50, 82, 6.6);
    },
  },
  {
    key: "contact", name: "Contact", color: "#0f9d58",
    draw(ctx) {
      ctx.fillStyle = "#fff"; dot(ctx, 50, 37, 15);
      ctx.beginPath(); ctx.moveTo(50, 57); ctx.quadraticCurveTo(24, 57, 24, 80); ctx.lineTo(24, 86); ctx.lineTo(76, 86); ctx.lineTo(76, 80);
      ctx.quadraticCurveTo(76, 57, 50, 57); ctx.closePath(); ctx.fill();
    },
  },
  {
    key: "instagram", name: "Instagram", color: "#d62976",
    draw(ctx) {
      ctx.strokeStyle = "#fff";
      roundRect(ctx, 23, 23, 54, 54, 16); ctx.lineWidth = 7; ctx.stroke();
      ring(ctx, 50, 50, 12.5, 7);
      ctx.fillStyle = "#fff"; dot(ctx, 68, 32, 4.6);
    },
  },
  {
    key: "whatsapp", name: "WhatsApp", color: "#25d366",
    draw(ctx) {
      // Official WhatsApp brand vector (speech bubble + telephone handset)
      const WHATSAPP_SVG_PATH =
        "M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91A9.92 9.92 0 0 0 12.04 2Zm0 18.17c-1.48 0-2.93-.4-4.2-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.18 8.18 0 0 1-1.26-4.4c0-4.52 3.68-8.2 8.2-8.2 2.19 0 4.25.85 5.8 2.4a8.15 8.15 0 0 1 2.4 5.8c0 4.52-3.68 8.2-8.2 8.2Zm4.49-6.14c-.25-.12-1.47-.72-1.7-.81-.23-.08-.39-.12-.56.12-.17.25-.64.81-.79.98-.14.17-.29.19-.54.06-.25-.12-1.04-.38-1.98-1.22-.73-.65-1.23-1.46-1.37-1.71-.15-.25-.02-.38.11-.5.11-.11.25-.29.37-.43.12-.15.17-.25.25-.42.08-.17.04-.31-.02-.43-.06-.12-.56-1.35-.77-1.85-.2-.49-.41-.42-.56-.43h-.48c-.17 0-.43.06-.66.31-.23.25-.87.85-.87 2.08 0 1.22.89 2.4 1.02 2.57.12.17 1.76 2.69 4.26 3.77.6.26 1.06.41 1.42.53.6.19 1.15.16 1.58.1.48-.07 1.47-.6 1.68-1.18.21-.58.21-1.07.15-1.18-.07-.12-.23-.19-.48-.31Z";
      glyph(ctx, WHATSAPP_SVG_PATH, 24, "#ffffff", 14);
    },
  },
  {
    key: "youtube", name: "YouTube", color: "#ff0000",
    draw(ctx) {
      ctx.fillStyle = "#fff"; roundRect(ctx, 18, 30, 64, 40, 13); ctx.fill();
      ctx.fillStyle = "#ff0000";
      ctx.beginPath(); ctx.moveTo(44, 40); ctx.lineTo(62, 50); ctx.lineTo(44, 60); ctx.closePath(); ctx.fill();
    },
  },
  {
    key: "telegram", name: "Telegram", color: "#229ed9",
    draw(ctx) {
      ctx.fillStyle = "#fff";
      ctx.beginPath(); ctx.moveTo(20, 50); ctx.lineTo(80, 27); ctx.lineTo(70, 74); ctx.lineTo(54, 62); ctx.lineTo(45, 76); ctx.lineTo(43, 57); ctx.closePath(); ctx.fill();
      ctx.fillStyle = "#229ed9"; ctx.beginPath(); ctx.moveTo(43, 57); ctx.lineTo(66, 36); ctx.lineTo(47, 59); ctx.closePath(); ctx.fill();
    },
  },
  {
    key: "twitter", name: "X (Twitter)", color: "#111111", tint: "#3f2a5c",
    draw(ctx) {
      ctx.fillStyle = "#fff"; ctx.lineCap = "round";
      bar(ctx, 50, 50, 62, 11, Math.PI / 4); bar(ctx, 50, 50, 62, 11, -Math.PI / 4);
    },
  },
  {
    key: "facebook", name: "Facebook", color: "#1877f2",
    draw(ctx) {
      ctx.fillStyle = "#fff";
      ctx.beginPath();
      ctx.moveTo(58, 86); ctx.lineTo(58, 54); ctx.lineTo(70, 54); ctx.lineTo(72, 41); ctx.lineTo(58, 41); ctx.lineTo(58, 33);
      ctx.quadraticCurveTo(58, 28, 64, 28); ctx.lineTo(71, 28); ctx.lineTo(71, 17); ctx.lineTo(61, 17);
      ctx.quadraticCurveTo(46, 17, 46, 33); ctx.lineTo(46, 41); ctx.lineTo(36, 41); ctx.lineTo(36, 54); ctx.lineTo(46, 54); ctx.lineTo(46, 86);
      ctx.closePath(); ctx.fill();
    },
  },
  {
    key: "tiktok", name: "TikTok", color: "#111111", tint: "#3f2a5c",
    draw(ctx) {
      ctx.strokeStyle = "#69c9d0"; ctx.lineWidth = 9; ctx.lineCap = "round";
      ctx.beginPath(); ctx.moveTo(58, 22); ctx.lineTo(58, 62); ctx.stroke();
      ctx.beginPath(); ctx.arc(46, 66, 15, Math.PI * 0.35, Math.PI * 1.75); ctx.stroke();
      ctx.strokeStyle = "#ee1d52";
      ctx.beginPath(); ctx.moveTo(56, 26); ctx.lineTo(56, 60); ctx.stroke();
      ctx.beginPath(); ctx.arc(44, 64, 15, Math.PI * 0.4, Math.PI * 1.7); ctx.stroke();
      ctx.strokeStyle = "#fff";
      ctx.beginPath(); ctx.moveTo(57, 24); ctx.lineTo(57, 64); ctx.quadraticCurveTo(58, 76, 44, 78); ctx.stroke();
    },
  },
  {
    key: "linkedin", name: "LinkedIn", color: "#0a66c2",
    draw(ctx) {
      ctx.fillStyle = "#fff";
      roundRect(ctx, 22, 38, 12, 40, 3); ctx.fill();
      dot(ctx, 28, 28, 7);
      ctx.beginPath(); ctx.moveTo(44, 38); ctx.lineTo(55, 38); ctx.lineTo(55, 43);
      ctx.quadraticCurveTo(59, 37, 67, 37); ctx.quadraticCurveTo(78, 37, 78, 52); ctx.lineTo(78, 78); ctx.lineTo(66, 78); ctx.lineTo(66, 55);
      ctx.quadraticCurveTo(66, 47, 59, 47); ctx.quadraticCurveTo(53, 47, 54, 55); ctx.lineTo(54, 78); ctx.lineTo(44, 78);
      ctx.closePath(); ctx.fill();
    },
  },
  {
    key: "location", name: "Maps pin", color: "#ffffff", tint: "#ea4335",
    draw(ctx) {
      // Crisp 4-color Google Maps pin style on white background
      // Red pin body
      ctx.fillStyle = "#ea4335";
      ctx.beginPath();
      ctx.moveTo(50, 89);
      ctx.bezierCurveTo(28, 62, 22, 49, 22, 38);
      ctx.arc(50, 38, 28, Math.PI, 0, false);
      ctx.bezierCurveTo(78, 49, 72, 62, 50, 89);
      ctx.closePath();
      ctx.fill();

      // Shadow / depth
      ctx.fillStyle = "#d93025";
      ctx.beginPath();
      ctx.moveTo(50, 89);
      ctx.bezierCurveTo(34, 66, 28, 52, 28, 38);
      ctx.arc(50, 38, 22, Math.PI, 0, false);
      ctx.bezierCurveTo(72, 52, 66, 66, 50, 89);
      ctx.closePath();
      ctx.fill();

      // Central white circle with colorful dot
      ctx.fillStyle = "#ffffff";
      ctx.beginPath();
      ctx.arc(50, 38, 12.5, 0, Math.PI * 2);
      ctx.fill();

      // Center blue core
      ctx.fillStyle = "#1a73e8";
      ctx.beginPath();
      ctx.arc(50, 38, 6.5, 0, Math.PI * 2);
      ctx.fill();
    },
  },
];

/** The colour a brand logo should tint a QR code with (never white, which would hide the code). */
export function brandTint(key: string): string {
  const logo = BRAND_LOGOS.find(l => l.key === key);
  const tint = logo?.tint || logo?.color || "#7c4de0";
  return tint.toLowerCase() === "#ffffff" ? "#7c4de0" : tint;
}

export const BRAND_LOGO_MAP: Record<string, BrandLogo> = BRAND_LOGOS.reduce((acc, logo) => { acc[logo.key] = logo; return acc; }, {} as Record<string, BrandLogo>);

/** Paints one brand logo inside a `size`×`size` square, including its rounded background. */
export function drawBrandLogo(ctx: CanvasRenderingContext2D, key: string, size: number, transparentBackground = false) {
  const logo = BRAND_LOGO_MAP[key];
  const scale = size / 100;
  ctx.save();
  ctx.scale(scale, scale);
  if (!transparentBackground) {
    if (key === "instagram") {
      const g = ctx.createLinearGradient(0, 100, 100, 0);
      g.addColorStop(0, "#feda75"); g.addColorStop(.35, "#fa7e1e"); g.addColorStop(.6, "#d62976"); g.addColorStop(.85, "#962fbf"); g.addColorStop(1, "#4f5bd5");
      roundRect(ctx, 0, 0, 100, 100, 24); ctx.fillStyle = g; ctx.fill();
    } else {
      roundRect(ctx, 0, 0, 100, 100, 24); ctx.fillStyle = logo ? logo.color : "#7c4de0"; ctx.fill();
    }
  }
  if (logo) logo.draw(ctx);
  else { ctx.fillStyle = "#fff"; dot(ctx, 50, 50, 22); }
  ctx.restore();
}

const cache = new Map<string, string>();

/** A PNG data URL for a brand logo, cached — used by the picker tiles and buttons. */
export function brandLogoPng(key: string, size = 256): string {
  const cached = cache.get(`${key}@${size}`);
  if (cached !== undefined) return cached;
  let url = "";
  try {
    const canvas = document.createElement("canvas");
    canvas.width = canvas.height = size;
    const ctx = canvas.getContext("2d");
    if (ctx) { drawBrandLogo(ctx, key, size); url = canvas.toDataURL("image/png"); }
  } catch { /* Canvas unavailable — the tile simply shows its label. */ }
  cache.set(`${key}@${size}`, url);
  return url;
}
