export interface ShapeAsset {
  key: string;
  name: string;
  d: string;
  evenOdd?: boolean;
  /**
   * How far a mitered outline pushes past the shape's box, as a multiple of the
   * outline width. A sharp vertex of interior angle θ reaches 1/sin(θ/2) — so a
   * triangle tip (≈55°) needs ~2.2 while an axis-aligned square only needs 1.
   */
  miter?: number;
}

/** Filled shapes drawn on a 100×100 grid and scaled to the element's width and height. */
export const shapes: ShapeAsset[] = [
  { key: "square", name: "Square", d: "M0 0h100v100H0Z" },
  { key: "rounded", name: "Rounded", d: "M22 0h56a22 22 0 0 1 22 22v56a22 22 0 0 1-22 22H22A22 22 0 0 1 0 78V22A22 22 0 0 1 22 0Z" },
  { key: "circle", name: "Circle", d: "M50 0a50 50 0 1 0 0 100A50 50 0 1 0 50 0Z" },
  { key: "triangle", name: "Triangle", d: "M50 3 98 96H2Z", miter: 2.2 },
  { key: "diamond", name: "Diamond", d: "M50 1 99 50 50 99 1 50Z", miter: 1.45 },
  { key: "pentagon", name: "Pentagon", d: "M50 2 98 37 80 94H20L2 37Z", miter: 1.3 },
  { key: "hexagon", name: "Hexagon", d: "M27 3h46l24 47-24 47H27L3 50Z", miter: 1.2 },
  { key: "octagon", name: "Octagon", d: "M32 3h36l29 29v36L68 97H32L3 68V32Z", miter: 1.1 },
  { key: "halfCircle", name: "Half circle", d: "M3 50a47 47 0 0 1 94 0Z", miter: 1.45 },
  { key: "quarter", name: "Quarter", d: "M3 97A94 94 0 0 1 97 3Z", miter: 1.45 },
  { key: "ring", name: "Ring", d: "M50 1a49 49 0 1 0 0 98 49 49 0 0 0 0-98Zm0 22a27 27 0 1 1 0 54 27 27 0 0 1 0-54Z", evenOdd: true },
  { key: "frame", name: "Frame", d: "M0 0h100v100H0Zm11 11v78h78V11Z", evenOdd: true },
  { key: "pill", name: "Pill", d: "M31 11h38a39 39 0 0 1 0 78H31a39 39 0 0 1 0-78Z" },
  { key: "oval", name: "Oval", d: "M50 13c26 0 45 17 45 37s-19 37-45 37S5 70 5 50s19-37 45-37Z" },
  { key: "heart", name: "Heart", d: "M50 93S7 66 7 38a22 22 0 0 1 43-11 22 22 0 0 1 43 11c0 28-43 55-43 55Z", miter: 2.4 },
  { key: "star5", name: "Star", d: "M50 3 62 37l36 1-29 22 11 35-30-21-30 21 11-35L2 38l36-1Z", miter: 3.3 },
  { key: "sparkle", name: "Sparkle", d: "M50 1c6 27 22 43 49 49-27 6-43 22-49 49-6-27-22-43-49-49 27-6 43-22 49-49Z", miter: 3.4 },
  { key: "star6", name: "Star burst", d: "M50 2 61 31l31-7-18 26 18 26-31-7-11 29-11-29-31 7 18-26L8 31l31 7Z", miter: 3 },
  { key: "badge", name: "Badge", d: "M50 2l10 12 15-5 3 16 16 3-6 15 12 9-12 9 6 15-16 3-3 16-15-5-10 12-10-12-15 5-3-16-16-3 6-15-12-9 12-9-6-15 16-3 3-16 15 5Z", miter: 2.1 },
  { key: "arrowRight", name: "Arrow", d: "M1 33h53V10l45 40-45 40V67H1Z", miter: 1.55 },
  { key: "arrowUp", name: "Arrow up", d: "M33 99V46H10L50 1l40 45H67v53Z", miter: 1.55 },
  { key: "arrowDouble", name: "Double arrow", d: "M21 50 45 19v21h10V19l24 31-24 31V60H45v21Z", miter: 2.4 },
  { key: "plus", name: "Plus", d: "M37 3h26v34h34v26H63v34H37V63H3V37h34Z", miter: 1.05 },
  { key: "cross", name: "Cross", d: "M18 3 50 35 82 3l15 15L65 50l32 32-15 15L50 65 18 97 3 82l32-32L3 18Z", miter: 1.45 },
  { key: "check", name: "Check", d: "M37 79 11 53l11-11 15 15 41-41 11 11Z", miter: 2.9 },
  { key: "speech", name: "Speech bubble", d: "M5 11h90v58H45L22 91V69H5Z", miter: 2 },
  { key: "cloud", name: "Cloud", d: "M28 79a21 21 0 0 1-1-42 28 28 0 0 1 53-4 20 20 0 0 1-3 46Z" },
  { key: "leaf", name: "Leaf", d: "M97 3C48 3 7 30 7 62c0 13 5 31 7 35 6-15 27-44 68-56-6 21-25 43-49 51 45 4 64-26 64-59Z", miter: 3.2 },
  { key: "wave", name: "Wave", d: "M0 61c14-17 28-17 42 0s28 17 42 0c7-8 16-14 16-14v53H0Z", miter: 1.3 },
  { key: "zigzag", name: "Zigzag", d: "M0 71 20 41l20 30 20-30 20 30 20-30v29H0Z", miter: 2.1 },
  { key: "blob", name: "Blob", d: "M50 3c27 0 47 19 47 41S82 97 50 97 3 77 3 50 23 3 50 3Z" },
  { key: "corner", name: "Corner", d: "M0 0h100v35H35v65H0Z", miter: 1.05 },
  { key: "trapezoid", name: "Trapezoid", d: "M23 3h54l21 94H2Z", miter: 1.7 },
  { key: "parallelogram", name: "Parallelogram", d: "M27 3h71L73 97H2Z", miter: 1.8 },
  { key: "shield", name: "Shield", d: "M50 3 93 17v35c0 26-22 41-43 45C29 93 7 78 7 52V17Z", miter: 1.8 },
  { key: "bookmarkShape", name: "Bookmark", d: "M17 3h66v94L50 71 17 97Z", miter: 1.9 },
  { key: "crescent", name: "Crescent", d: "M63 3a47 47 0 1 0 0 94 55 55 0 0 1 0-94Z", miter: 3 },
];

export const shapeByKey = (key?: string) => shapes.find(shape => shape.key === key);

/** Smooth shapes still need a touch of room for the rounded outer rim. */
export const DEFAULT_SHAPE_MITER = 1.15;
