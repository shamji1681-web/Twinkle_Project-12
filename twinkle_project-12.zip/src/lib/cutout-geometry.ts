import type { DesignLayer } from "@/lib/designs";

/** The part of the original photo (as fractions 0–1 of its width/height) that a cutout was trimmed to. */
export interface CutoutCrop { x: number; y: number; width: number; height: number }
export interface LayerBox { x: number; y: number; width: number; height: number }

const round2 = (value: number) => Math.round(value * 100) / 100;

/** Rotates a vector like SVG `rotate(deg)` does (y axis points down). */
function rotate(dx: number, dy: number, degrees: number): [number, number] {
  const a = degrees * Math.PI / 180, cos = Math.cos(a), sin = Math.sin(a);
  return [dx * cos - dy * sin, dx * sin + dy * cos];
}

/**
 * The layer can shrink to the subject only when its frame shows the whole photo 1:1
 * (same aspect ratio, no crop zoom, no mirroring). Otherwise the cutout keeps its full frame.
 */
export function canTrimLayerToSubject(layer: DesignLayer, frameWidth: number, frameHeight: number): boolean {
  if (!layer.width || !layer.height || !frameWidth || !frameHeight) return false;
  if ((layer.cropZoom || 1) > 1.001) return false;
  if (layer.effects?.flipX || layer.effects?.flipY) return false;
  const layerAspect = layer.width / layer.height, frameAspect = frameWidth / frameHeight;
  return Math.abs(layerAspect - frameAspect) / frameAspect < 0.03;
}

/** New frame for a layer whose picture was trimmed to `crop`; the subject stays exactly where it was. */
export function trimBox(layer: DesignLayer, crop: CutoutCrop): LayerBox {
  const width = layer.width * crop.width, height = layer.height * crop.height;
  const [rx, ry] = rotate((crop.x + crop.width / 2 - 0.5) * layer.width, (crop.y + crop.height / 2 - 0.5) * layer.height, layer.rotation || 0);
  const cx = layer.x + layer.width / 2 + rx, cy = layer.y + layer.height / 2 + ry;
  return { x: round2(cx - width / 2), y: round2(cy - height / 2), width: round2(Math.max(1, width)), height: round2(Math.max(1, height)) };
}

/** Inverse of `trimBox`: the full-photo frame that matches the current (possibly moved or resized) trimmed layer. */
export function untrimBox(layer: DesignLayer, crop: CutoutCrop): LayerBox {
  const width = layer.width / Math.max(0.001, crop.width), height = layer.height / Math.max(0.001, crop.height);
  const [rx, ry] = rotate((crop.x + crop.width / 2 - 0.5) * width, (crop.y + crop.height / 2 - 0.5) * height, layer.rotation || 0);
  const cx = layer.x + layer.width / 2 - rx, cy = layer.y + layer.height / 2 - ry;
  return { x: round2(cx - width / 2), y: round2(cy - height / 2), width: round2(width), height: round2(height) };
}
