export interface BackgroundRemovalProgress {
  stage: "preparing" | "loading" | "segmenting" | "refining" | "encoding";
  message: string;
  percent?: number;
}

export type BackgroundRemovalWorkerReply =
  | { type: "progress"; progress: BackgroundRemovalProgress }
  | { type: "result"; image: Blob }
  | { type: "error"; message: string };