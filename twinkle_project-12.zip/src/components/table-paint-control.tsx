import { useLayoutEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { ChevronDown, Type, X } from "lucide-react";
import FillPicker from "@/components/fill-picker";
import type { EditorContext } from "@/components/editor-panels";
import { gradientCss, hexWithAlpha, type DesignLayer } from "@/lib/designs";
import { hexToRgb, rgbToHex } from "@/lib/color";
import { sidePopoverPlacement } from "@/lib/popover-placement";
import { applyTableFill, applyTablePaint, applyTableTextColor, tableCellFill, tableCellGradient, tableCellTextColor, tableSelection } from "@/lib/table";

function solidAlpha(color: string) {
  if (color === "transparent") return 0;
  if (color.length === 9) return parseInt(color.slice(7), 16) / 255;
  if (color.length === 5) return parseInt(color.slice(4).repeat(2), 16) / 255;
  return 1;
}

export default function TablePaintControl({ ctx }: { ctx: EditorContext }) {
  const layer = ctx.selected!;
  const [menu, setMenu] = useState<"fill" | "text" | null>(null);
  const [position, setPosition] = useState({ left: 10, top: 112 });
  const fillRef = useRef<HTMLButtonElement>(null), textRef = useRef<HTMLButtonElement>(null);
  const first = ctx.selectedCells[0] || { r: 0, c: 0 };
  const solid = tableCellFill(layer, first.r, first.c), gradient = tableCellGradient(layer, first.r, first.c), text = tableCellTextColor(layer, first.r, first.c);
  const bounds = tableSelection(layer, ctx.selectedCells);
  const selectedKey = `${bounds.r1}-${bounds.c1}-${bounds.r2}-${bounds.c2}`;
  const targetColor = menu === "text" ? text : solid;
  const virtual: DesignLayer = {
    id: `${layer.id}-${menu}-${selectedKey}`, type: "rect", x: 0, y: 0, width: 160, height: 80,
    fill: targetColor === "transparent" ? "#ffffff" : rgbToHex(hexToRgb(targetColor)),
    fillAlpha: targetColor === "transparent" ? 1 : solidAlpha(targetColor), fillGradient: menu === "fill" ? gradient : undefined,
  };

  function toggle(next: "fill" | "text") { ctx.setTableStyleOpen(false); setMenu(menu === next ? null : next); }
  useLayoutEffect(() => {
    if (!menu) return;
    function place() {
      const rect = (menu === "fill" ? fillRef.current : textRef.current)?.getBoundingClientRect();
      if (rect) { const { left, top } = sidePopoverPlacement(rect, { width: 270, height: 640 }); setPosition({ left, top }); }
    }
    function outside(e: PointerEvent) { if (!(e.target as Element).closest('[data-table-paint-popover],[data-table-paint-trigger]')) setMenu(null); }
    function escape(e: KeyboardEvent) { if ((e.target as Element).matches?.('input[type="number"]')) return; if (e.key === "Escape") { e.preventDefault(); e.stopImmediatePropagation(); setMenu(null); } }
    place();
    window.addEventListener('resize', place); document.addEventListener('scroll', place, true); document.addEventListener('pointerdown', outside, true); document.addEventListener('keydown', escape, true);
    return () => { window.removeEventListener('resize', place); document.removeEventListener('scroll', place, true); document.removeEventListener('pointerdown', outside, true); document.removeEventListener('keydown', escape, true); };
  }, [menu]);

  function patchFill(patch: Partial<DesignLayer>) { ctx.patch(layer.id, applyTablePaint(layer, ctx.selectedCells, patch)); }
  return <>
    <button ref={fillRef} className={`table-cell-paint-button ${menu === "fill" ? "active" : ""}`} data-table-paint-trigger aria-label="Selected cell fill" aria-expanded={menu === "fill"} title="Selected cells · solid or gradient fill" disabled={layer.locked} onClick={() => toggle("fill")}><span className={`table-cell-paint-swatch ${solid === "transparent" && !gradient ? "is-transparent" : ""}`} style={{ background: gradient ? gradientCss(gradient) : solid }} /><ChevronDown size={11} /></button>
    <button ref={textRef} className={`table-text-paint-button ${menu === "text" ? "active" : ""}`} data-table-paint-trigger aria-label="Table text color" aria-expanded={menu === "text"} title="Selected cells · text colour" disabled={layer.locked} onClick={() => toggle("text")}><span><Type size={16} /><i style={{ background: text }} /></span><ChevronDown size={11} /></button>
    {menu && createPortal(<div className="context-popover fixed table-paint-popover" data-table-paint-popover data-context-popover role="group" aria-label={menu === "fill" ? "Selected cell fill picker" : "Table text color picker"} style={{ left: position.left, top: position.top, width: 270, maxHeight: Math.max(150, window.innerHeight - position.top - 12) }}>
      <div className="table-paint-heading"><div><strong>{menu === "fill" ? "Cell fill" : "Text colour"}</strong><small>{ctx.selectedCells.length ? `Selected · R${bounds.r1 + 1}–${bounds.r2 + 1}, C${bounds.c1 + 1}–${bounds.c2 + 1}` : "All table cells"}</small></div><button aria-label="Close cell color picker" onClick={() => setMenu(null)}><X size={15} /></button></div>
      {menu === "fill" && <button className="table-transparent-button" aria-label="Make selected cells transparent" onClick={() => ctx.patch(layer.id, applyTableFill(layer, ctx.selectedCells, "transparent"))}><span className="transparency-chip" />No fill · Transparent</button>}
      <FillPicker key={virtual.id} layer={virtual} brandColors={ctx.workspace?.colors || []} allowImage={false} allowGradient={menu === "fill"} onUploadFill={() => {}} onPatch={menu === "fill" ? patchFill : patch => {
        if (patch.fill !== undefined || Object.hasOwn(patch, "fillAlpha")) ctx.patch(layer.id, applyTableTextColor(layer, ctx.selectedCells, hexWithAlpha(patch.fill ?? virtual.fill, patch.fillAlpha ?? 1)));
      }} />
      <p className="table-paint-note">{ctx.selectedCells.length ? "Only the selected cells will change." : "Select a cell first to colour just that cell."}</p>
    </div>, document.body)}
  </>;
}
