import { useRef, useState, type KeyboardEvent, type PointerEvent } from "react";
import type { DesignLayer } from "@/lib/designs";
import { clamp, clampFadePoint, fadeAngle, isOpacityFade, rotateOpacityFade, type FadePoint, type OpacityFade } from "@/lib/opacity-fade";

type Handle = "start" | "end" | "midpoint" | "rotate";
interface Props {
  layer: DesignLayer;
  scale: number;
  onChange: (fade: OpacityFade) => void;
  onStart: () => void;
  onEnd: () => void;
}
interface Drag {
  kind: Handle;
  fade: OpacityFade;
  pointer: FadePoint;
  center: FadePoint;
  rotation: number;
  scale: number;
}

export default function OpacityFadeOverlay({ layer, scale, onChange, onStart, onEnd }: Props) {
  const ref = useRef<HTMLDivElement>(null);
  const drag = useRef<Drag | null>(null);
  const [active, setActive] = useState<Handle | null>(null);
  const fade = layer.opacityFade;
  if (!fade) return null;
  const width = layer.width * scale, height = layer.height * scale;
  const start = { x: fade.start.x * width, y: fade.start.y * height };
  const end = { x: fade.end.x * width, y: fade.end.y * height };
  const mid = { x: start.x + (end.x - start.x) * fade.midpoint, y: start.y + (end.y - start.y) * fade.midpoint };
  const radians = Math.atan2(end.y - start.y, end.x - start.x);
  const angle = radians * 180 / Math.PI;
  const arm = clamp(Math.hypot(end.x - start.x, end.y - start.y) * .42, 42, 94);
  const rotationPoint = { x: start.x + Math.sin(radians) * arm, y: start.y - Math.cos(radians) * arm };

  function localPoint(event: { clientX: number; clientY: number }, state: Drag): FadePoint {
    const dx = (event.clientX - state.center.x) / state.scale;
    const dy = (event.clientY - state.center.y) / state.scale;
    const a = -state.rotation * Math.PI / 180;
    return { x: dx * Math.cos(a) - dy * Math.sin(a) + layer.width / 2, y: dx * Math.sin(a) + dy * Math.cos(a) + layer.height / 2 };
  }

  function begin(event: PointerEvent<HTMLButtonElement>, kind: Handle) {
    if (event.button !== 0 || !fade) return;
    event.preventDefault(); event.stopPropagation();
    const box = ref.current!.getBoundingClientRect();
    const state: Drag = {
      kind, fade: { ...fade, start: { ...fade.start }, end: { ...fade.end } },
      pointer: { x: 0, y: 0 }, center: { x: box.left + box.width / 2, y: box.top + box.height / 2 },
      rotation: layer.rotation || 0, scale,
    };
    state.pointer = localPoint(event, state);
    drag.current = state;
    event.currentTarget.setPointerCapture(event.pointerId);
    setActive(kind);
    onStart();
  }

  function move(event: PointerEvent<HTMLButtonElement>) {
    const state = drag.current;
    if (!state) return;
    const p = localPoint(event, state);
    const source = state.fade;
    let next: OpacityFade = { ...source };
    if (state.kind === "start" || state.kind === "end") {
      const key = state.kind;
      next[key] = clampFadePoint({
        x: source[key].x + (p.x - state.pointer.x) / layer.width,
        y: source[key].y + (p.y - state.pointer.y) / layer.height,
      });
    } else if (state.kind === "midpoint") {
      const ax = source.start.x * layer.width, ay = source.start.y * layer.height;
      const dx = (source.end.x - source.start.x) * layer.width, dy = (source.end.y - source.start.y) * layer.height;
      next.midpoint = Math.round(clamp(((p.x - ax) * dx + (p.y - ay) * dy) / Math.max(.001, dx * dx + dy * dy), .05, .95) * 1000) / 1000;
    } else {
      const sx = source.start.x * layer.width, sy = source.start.y * layer.height;
      let theta = Math.atan2(p.y - sy, p.x - sx) + Math.PI / 2;
      let degrees = theta * 180 / Math.PI;
      const snap = event.shiftKey ? 15 : 90;
      if (event.shiftKey || Math.abs(degrees - Math.round(degrees / snap) * snap) < 3) degrees = Math.round(degrees / snap) * snap;
      theta = degrees * Math.PI / 180;
      const length = Math.hypot((source.end.x - source.start.x) * layer.width, (source.end.y - source.start.y) * layer.height);
      next.end = clampFadePoint({ x: (sx + Math.cos(theta) * length) / layer.width, y: (sy + Math.sin(theta) * length) / layer.height });
    }
    if (isOpacityFade(next)) onChange(next);
  }

  function finish(event: PointerEvent<HTMLButtonElement>) {
    if (!drag.current) return;
    drag.current = null;
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
    setActive(null);
    onEnd();
  }

  function keyMove(event: KeyboardEvent<HTMLButtonElement>, kind: Handle) {
    if (!fade || !["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(event.key)) return;
    event.preventDefault(); event.stopPropagation();
    const positive = event.key === "ArrowRight" || event.key === "ArrowDown";
    const step = event.shiftKey ? 10 : 1;
    let next: OpacityFade = { ...fade };
    if (kind === "midpoint") next.midpoint = clamp(fade.midpoint + (positive ? .01 : -.01) * step, .05, .95);
    else if (kind === "rotate") next = rotateOpacityFade(fade, fadeAngle(fade, layer) + (positive ? 1 : -1) * step, layer);
    else next[kind] = clampFadePoint({
      x: fade[kind].x + (event.key === "ArrowRight" ? step : event.key === "ArrowLeft" ? -step : 0) / (layer.width * scale),
      y: fade[kind].y + (event.key === "ArrowDown" ? step : event.key === "ArrowUp" ? -step : 0) / (layer.height * scale),
    });
    if (isOpacityFade(next)) { onStart(); onChange(next); onEnd(); }
  }

  const events = (kind: Handle) => ({ onPointerDown: (e: PointerEvent<HTMLButtonElement>) => begin(e, kind), onPointerMove: move, onPointerUp: finish, onPointerCancel: finish, onLostPointerCapture: finish, onKeyDown: (e: KeyboardEvent<HTMLButtonElement>) => keyMove(e, kind) });
  return <div ref={ref} className={`opacity-fade-overlay ${active ? "is-dragging" : ""}`} data-editor-only="true" data-opacity-fade-controls="true" style={{ left: layer.x * scale, top: layer.y * scale, width, height, transform: `rotate(${layer.rotation || 0}deg)` }}>
    <svg className="fade-axis-lines" width={width} height={height} aria-hidden="true">
      <line className="fade-axis-halo" x1={start.x} y1={start.y} x2={end.x} y2={end.y} />
      <line x1={start.x} y1={start.y} x2={end.x} y2={end.y} />
      <line className="fade-rotation-line" x1={start.x} y1={start.y} x2={rotationPoint.x} y2={rotationPoint.y} />
    </svg>
    <button type="button" className="fade-handle fade-start" style={{ left: start.x, top: start.y }} aria-label="Move fade start" title={`Fade start · ${Math.round(fade.startOpacity * 100)}% opacity`} {...events("start")}><span /></button>
    <button type="button" className="fade-handle fade-end" style={{ left: end.x, top: end.y, transform: `translate(-50%, -50%) rotate(${angle}deg)` }} aria-label="Move fade end" title={`Fade end · ${Math.round(fade.endOpacity * 100)}% opacity`} {...events("end")}><svg viewBox="0 0 26 26" aria-hidden="true"><path d="M4 3 23 13 4 23Z" /></svg></button>
    <button type="button" className="fade-handle fade-midpoint" style={{ left: mid.x, top: mid.y, transform: `translate(-50%, -50%) rotate(${angle}deg)` }} aria-label="Adjust fade midpoint" title={`Fade midpoint · ${Math.round(fade.midpoint * 100)}%`} {...events("midpoint")}><span /></button>
    <button type="button" className="fade-handle fade-rotate" style={{ left: rotationPoint.x, top: rotationPoint.y }} aria-label="Rotate opacity fade" title="Rotate fade · hold Shift to snap" {...events("rotate")}><span /></button>
    {active && <span className="fade-readout" style={{ left: mid.x, top: mid.y + 22, transform: `translateX(-50%) rotate(${-(layer.rotation || 0)}deg)` }}>{active === "midpoint" ? `${Math.round(fade.midpoint * 100)}% midpoint` : `${fadeAngle(fade, layer)}° · ${Math.round(fade.startOpacity * 100)}% → ${Math.round(fade.endOpacity * 100)}%`}</span>}
  </div>;
}
