import { useCallback, useEffect, useRef, useState, type ElementType, type PointerEvent as ReactPointerEvent } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface Props {
  categories: string[];
  icons: ElementType[];
  active: string;
  onSelect: (name: string) => void;
}

/**
 * Horizontal category strip for the Home / Templates pages.
 * - Buttons never shrink or overlap: the strip scrolls sideways instead.
 * - A custom scrollbar is always visible (native mobile scrollbars auto-hide), and it can be dragged or tapped.
 * - Arrow buttons + soft edge fades hint that more categories are available.
 */
export default function HomeCategoryScroller({ categories, icons, active, onSelect }: Props) {
  const rowRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const drag = useRef<{ startX: number; startScroll: number; ratio: number } | null>(null);
  const [state, setState] = useState({ left: false, right: false, thumbW: 100, thumbX: 0, scrollable: false });
  const [dragging, setDragging] = useState(false);

  const measure = useCallback(() => {
    const row = rowRef.current;
    if (!row) return;
    const max = row.scrollWidth - row.clientWidth;
    const scrollable = max > 2;
    const thumbW = scrollable ? Math.max(14, (row.clientWidth / row.scrollWidth) * 100) : 100;
    const progress = scrollable ? Math.min(1, Math.max(0, row.scrollLeft / max)) : 0;
    setState({
      left: row.scrollLeft > 2,
      right: row.scrollLeft < max - 2,
      thumbW,
      thumbX: progress * (100 - thumbW),
      scrollable,
    });
  }, []);

  useEffect(() => {
    const row = rowRef.current;
    if (!row) return;
    measure();
    row.addEventListener("scroll", measure, { passive: true });
    const observer = typeof ResizeObserver !== "undefined" ? new ResizeObserver(measure) : null;
    observer?.observe(row);
    window.addEventListener("resize", measure);
    return () => { row.removeEventListener("scroll", measure); observer?.disconnect(); window.removeEventListener("resize", measure); };
  }, [measure, categories.length]);

  // Keep the selected category inside the visible part of the strip (without scrolling the page).
  useEffect(() => {
    const row = rowRef.current;
    const item = row?.querySelector<HTMLElement>(".category-active");
    if (!row || !item) return;
    const pad = 16;
    const itemLeft = item.offsetLeft - row.offsetLeft;
    const itemRight = itemLeft + item.offsetWidth;
    if (itemLeft - pad < row.scrollLeft) row.scrollTo({ left: Math.max(0, itemLeft - pad), behavior: "smooth" });
    else if (itemRight + pad > row.scrollLeft + row.clientWidth) row.scrollTo({ left: itemRight + pad - row.clientWidth, behavior: "smooth" });
  }, [active]);

  const nudge = (direction: number) => {
    const row = rowRef.current;
    if (row) row.scrollBy({ left: direction * Math.max(160, row.clientWidth * 0.7), behavior: "smooth" });
  };

  function onThumbDown(event: ReactPointerEvent<HTMLSpanElement>) {
    const row = rowRef.current, track = trackRef.current;
    if (!row || !track) return;
    event.preventDefault();
    event.stopPropagation();
    event.currentTarget.setPointerCapture(event.pointerId);
    const thumbPx = track.clientWidth * (state.thumbW / 100);
    const travel = Math.max(1, track.clientWidth - thumbPx);
    drag.current = { startX: event.clientX, startScroll: row.scrollLeft, ratio: (row.scrollWidth - row.clientWidth) / travel };
    setDragging(true);
  }
  function onThumbMove(event: ReactPointerEvent<HTMLSpanElement>) {
    const row = rowRef.current;
    if (!drag.current || !row) return;
    row.scrollLeft = drag.current.startScroll + (event.clientX - drag.current.startX) * drag.current.ratio;
  }
  function onThumbUp(event: ReactPointerEvent<HTMLSpanElement>) {
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
    drag.current = null;
    setDragging(false);
  }
  function onTrackDown(event: ReactPointerEvent<HTMLDivElement>) {
    const row = rowRef.current, track = trackRef.current;
    if (!row || !track || event.target !== event.currentTarget) return;
    const rect = track.getBoundingClientRect();
    const ratio = Math.min(1, Math.max(0, (event.clientX - rect.left) / rect.width));
    row.scrollTo({ left: ratio * row.scrollWidth - row.clientWidth / 2, behavior: "smooth" });
  }

  return <div className={`home-cat-scroller${state.left ? " can-left" : ""}${state.right ? " can-right" : ""}`}>
    <div className="home-cat-viewport">
      <button type="button" className="home-cat-arrow left" aria-label="Scroll categories left" tabIndex={-1} onClick={() => nudge(-1)}><ChevronLeft size={18} /></button>
      <div className="category-row" role="group" aria-label="Design categories" ref={rowRef}>
        {categories.map((name, index) => {
          const Icon = icons[index];
          return <button key={name} className={`category-item category-${index} ${active === name ? "category-active" : ""}`} onClick={() => onSelect(name)} aria-pressed={active === name}>
            <span className="category-icon"><Icon size={24} strokeWidth={1.65} /></span><span>{name}</span>
          </button>;
        })}
      </div>
      <button type="button" className="home-cat-arrow right" aria-label="Scroll categories right" tabIndex={-1} onClick={() => nudge(1)}><ChevronRight size={18} /></button>
    </div>
    <div className={`home-cat-scrollbar${state.scrollable ? "" : " is-idle"}${dragging ? " is-dragging" : ""}`} ref={trackRef} onPointerDown={onTrackDown} aria-hidden="true">
      <span className="home-cat-thumb" style={{ width: `${state.thumbW}%`, left: `${state.thumbX}%` }} onPointerDown={onThumbDown} onPointerMove={onThumbMove} onPointerUp={onThumbUp} onPointerCancel={onThumbUp} />
    </div>
  </div>;
}
