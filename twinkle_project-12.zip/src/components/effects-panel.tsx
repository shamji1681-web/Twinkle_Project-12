import { RotateCcw, Sparkles, Wand2 } from "lucide-react";
import type { LayerEffects } from "@/lib/designs";
import { hasEffects } from "@/lib/designs";
import RangeControl from "@/components/range-control";
import { TextCurveControls, TextOutlineControls, TextRotationControls } from "@/components/text-effects-controls";
import { ColorField, Swatches, type EditorContext } from "@/components/editor-panels";

const PRESETS: { name: string; effects: LayerEffects }[] = [
  { name: "None", effects: {} },
  { name: "Soft shadow", effects: { shadow: { color: "#000000", blur: 8, x: 4, y: 6, opacity: 0.28 } } },
  { name: "Drop shadow", effects: { shadow: { color: "#1c0f33", blur: 2, x: 8, y: 8, opacity: 0.6 } } },
  { name: "Lift", effects: { shadow: { color: "#000000", blur: 18, x: 0, y: 12, opacity: 0.22 } } },
  { name: "Glow", effects: { glow: { color: "#ffd166", blur: 12, opacity: 0.85 } } },
  { name: "Neon", effects: { glow: { color: "#7c4de0", blur: 16, opacity: 1 }, outline: { color: "#ffffff", width: 2 } } },
  { name: "Outline", effects: { outline: { color: "#24232b", width: 5 } } },
  { name: "Sticker", effects: { outline: { color: "#ffffff", width: 10 }, shadow: { color: "#000000", blur: 6, x: 3, y: 5, opacity: 0.3 } } },
  { name: "Retro", effects: { sepia: 0.7, contrast: 1.1, saturation: 0.9 } },
  { name: "Mono", effects: { grayscale: 1, contrast: 1.15 } },
  { name: "Dreamy", effects: { blur: 1.5, brightness: 1.1, saturation: 1.2 } },
  { name: "Punchy", effects: { contrast: 1.35, saturation: 1.4 } },
];

function Slider({ label, value, min, max, step = 1, unit = "", onChange, onCommit }: { label: string; value: number; min: number; max: number; step?: number; unit?: string; onChange: (value: number) => void; onCommit?: (value: number) => void }) {
  return <RangeControl label={label} value={value} min={min} max={max} step={step} unit={unit} onChange={onChange} onCommit={onCommit} />;
}

/** Colour row (picker + brand swatches) shared by glow, shadow, outline and text outline. */
function EffectColor({ ctx, label, value, onChange }: { ctx: EditorContext; label: string; value: string; onChange: (color: string) => void }) {
  return <div className="fx-color-block">
    <h4 className="fx-color-label">{label}</h4>
    <ColorField label={label} value={value} onChange={onChange} />
    <Swatches ctx={ctx} onPick={onChange} />
  </div>;
}

export default function EffectsPanel({ ctx }: { ctx: EditorContext }) {
  const layer = ctx.selected;
  if (!layer) return <div className="empty-layers"><Sparkles size={26} /><p>Select an element on the canvas to add shadows, glows, outlines and colour adjustments.</p></div>;

  const fx: LayerEffects = layer.effects || {};
  const set = (patch: Partial<LayerEffects>) => {
    const next: LayerEffects = { ...fx, ...patch };
    (Object.keys(next) as (keyof LayerEffects)[]).forEach(key => { if (next[key] === undefined) delete next[key]; });
    ctx.patch(layer.id, { effects: hasEffects(next) ? next : undefined });
  };
  const isImage = layer.type === "image";
  const isQR = isImage && !!layer.qr;
  // Corner rounding is supported for every image (QR codes included) and for
  // rectangle-based shapes — rounded paths like circles/stars have no corners to round.
  const isRoundableShape = layer.type === "rect" || (layer.type === "shape" && layer.shape === "square");
  const cornerMax = Math.round(Math.min(layer.width, layer.height) / 2);
  const isLine = layer.type === "stroke" || layer.type === "draw";
  // A line without an explicit weight is drawn at ~30% of its box height.
  const lineWeight = Math.round((layer.strokeWidth ?? Math.max(2, layer.height * .3)) * 10) / 10;
  const setLineWeight = (value: number) => ctx.patch(layer.id, { strokeWidth: Math.max(.5, Math.min(400, Math.round(value * 10) / 10)) });
  const basicLineStyles: { key: string; name: string }[] = [
    { key: "solid", name: "Solid" }, { key: "dashed", name: "Dashed" }, { key: "dotted", name: "Dotted" },
    { key: "double", name: "Double" }, { key: "arrow", name: "Arrow" }, { key: "wave", name: "Wave" }, { key: "zigzag", name: "Zigzag" },
  ];
  const variant = layer.variant || "solid";
  const isBasicLine = layer.type === "stroke" && !variant.startsWith("border-") && !variant.startsWith("corner-");

  return <>
    <p className="editor-panel-description">Effects for the selected {layer.type === "text" ? "text" : layer.type === "image" ? "image" : "element"}. Everything is live and undoable — colours included.</p>

    <h3 className="panel-subtitle">Presets</h3>
    <div className="fx-presets">{PRESETS.map(preset => {
      const active = JSON.stringify(preset.effects) === JSON.stringify(fx);
      return <button key={preset.name} className={active ? "active" : ""} onClick={() => ctx.patch(layer.id, { effects: hasEffects(preset.effects) ? { ...preset.effects } : undefined })}>
        <span className={`fx-preview fx-${preset.name.toLowerCase().replace(/\s+/g, "-")}`}>Aa</span><small>{preset.name}</small>
      </button>;
    })}</div>

    {isLine && <section className="fx-section">
      <h3 className="panel-subtitle">Line</h3>
      <Slider label="Thickness" value={lineWeight} min={.5} max={80} step={.5} unit="px" onChange={setLineWeight} />
      <div className="fx-quick">{[1, 2, 4, 8, 16, 28].map(weight => <button key={weight} className={Math.round(lineWeight) === weight ? "active" : ""} onClick={() => setLineWeight(weight)}>{weight}px</button>)}</div>
      {isBasicLine && <>
        <h4 className="fx-color-label">Line style</h4>
        <div className="fx-quick line-style-quick">{basicLineStyles.map(style => <button key={style.key} className={variant === style.key ? "active" : ""} onClick={() => ctx.patch(layer.id, { variant: style.key })}>{style.name}</button>)}</div>
      </>}
      <p className="small-hint">Thickness stays put when you drag the line longer, so borders and dividers keep their weight.</p>
    </section>}

    <section className="fx-section">
      <div className="fx-heading"><h3 className="panel-subtitle">Glow</h3><button className={`fx-toggle ${fx.glow ? "on" : ""}`} aria-pressed={!!fx.glow} aria-label="Toggle glow" onClick={() => set({ glow: fx.glow ? undefined : { color: "#7c4de0", blur: 12, opacity: 0.9 } })}><i /></button></div>
      {fx.glow && <>
        <Slider label="Spread" value={fx.glow.blur} min={1} max={60} onChange={v => set({ glow: { ...fx.glow!, blur: v } })} />
        <Slider label="Strength" value={fx.glow.opacity} min={0} max={1} step={0.05} onChange={v => set({ glow: { ...fx.glow!, opacity: v } })} />
        <EffectColor ctx={ctx} label="Glow colour" value={fx.glow.color} onChange={color => set({ glow: { ...fx.glow!, color } })} />
      </>}
    </section>

    <section className="fx-section">
      <div className="fx-heading"><h3 className="panel-subtitle">Shadow</h3><button className={`fx-toggle ${fx.shadow ? "on" : ""}`} aria-pressed={!!fx.shadow} aria-label="Toggle shadow" onClick={() => set({ shadow: fx.shadow ? undefined : { color: "#000000", blur: 8, x: 4, y: 6, opacity: 0.3 } })}><i /></button></div>
      {fx.shadow && <>
        <Slider label="Blur" value={fx.shadow.blur} min={0} max={60} onChange={v => set({ shadow: { ...fx.shadow!, blur: v } })} />
        <Slider label="Offset X" value={fx.shadow.x} min={-60} max={60} onChange={v => set({ shadow: { ...fx.shadow!, x: v } })} />
        <Slider label="Offset Y" value={fx.shadow.y} min={-60} max={60} onChange={v => set({ shadow: { ...fx.shadow!, y: v } })} />
        <Slider label="Opacity" value={fx.shadow.opacity} min={0} max={1} step={0.05} onChange={v => set({ shadow: { ...fx.shadow!, opacity: v } })} />
        <EffectColor ctx={ctx} label="Shadow colour" value={fx.shadow.color} onChange={color => set({ shadow: { ...fx.shadow!, color } })} />
      </>}
    </section>

    <section className="fx-section">
      <div className="fx-heading"><h3 className="panel-subtitle">Outline</h3><button className={`fx-toggle ${fx.outline ? "on" : ""}`} aria-pressed={!!fx.outline} aria-label="Toggle outline" onClick={() => set({ outline: fx.outline ? undefined : { color: "#24232b", width: 4 } })}><i /></button></div>
      {fx.outline && <>
        <Slider label="Thickness" value={fx.outline.width} min={0.5} max={30} step={0.5} onChange={v => set({ outline: { ...fx.outline!, width: v } })} />
        <EffectColor ctx={ctx} label="Outline colour" value={fx.outline.color} onChange={color => set({ outline: { ...fx.outline!, color } })} />
      </>}
    </section>

    {(isImage || isRoundableShape) && <section className="fx-section">
      <h3 className="panel-subtitle">Corners</h3>
      <Slider label="Corner radius" value={layer.radius || 0} min={0} max={cornerMax} unit="px" onChange={v => ctx.patch(layer.id, { radius: Math.round(v * 100) / 100 })} onCommit={v => {
        const circle = v >= cornerMax - 0.5;
        if (isImage) ctx.patch(layer.id, { radius: Math.round(v * 100) / 100, mask: circle ? "circle" : (layer.mask === "circle" ? "none" : layer.mask) });
        else ctx.patch(layer.id, { radius: Math.round(v * 100) / 100 });
      }} />
      <div className="corner-quick-row">
        <button type="button" onClick={() => ctx.patch(layer.id, isImage ? { radius: 0, mask: layer.mask === "circle" ? "none" : layer.mask } : { radius: 0 })}>Square</button>
        <button type="button" onClick={() => ctx.patch(layer.id, isImage ? { radius: Math.min(16, cornerMax), mask: layer.mask === "circle" ? "none" : layer.mask } : { radius: Math.min(16, cornerMax) })}>Rounded</button>
        <button type="button" onClick={() => ctx.patch(layer.id, isImage ? { radius: cornerMax, mask: "circle" } : { radius: cornerMax })}>Circle</button>
      </div>
      <p className="small-hint">{isImage ? <>Drag to the maximum value, or tap <strong>Circle</strong>, to clip the full {isQR ? "QR code" : "image"} into an ellipse.</> : <>Drag to the maximum value, or tap <strong>Circle</strong>, to round the shape fully.</>}</p>
    </section>}

    <section className="fx-section">
      <h3 className="panel-subtitle">Adjust</h3>
      <Slider label="Blur" value={fx.blur ?? 0} min={0} max={30} step={0.5} onChange={v => set({ blur: v || undefined })} />
      <Slider label="Brightness" value={fx.brightness ?? 1} min={0.2} max={2} step={0.05} onChange={v => set({ brightness: v === 1 ? undefined : v })} />
      <Slider label="Contrast" value={fx.contrast ?? 1} min={0.2} max={2} step={0.05} onChange={v => set({ contrast: v === 1 ? undefined : v })} />
      <Slider label="Saturation" value={fx.saturation ?? 1} min={0} max={2} step={0.05} onChange={v => set({ saturation: v === 1 ? undefined : v })} />
      <Slider label="Grayscale" value={fx.grayscale ?? 0} min={0} max={1} step={0.05} onChange={v => set({ grayscale: v || undefined })} />
      <Slider label="Sepia" value={fx.sepia ?? 0} min={0} max={1} step={0.05} onChange={v => set({ sepia: v || undefined })} />
    </section>

    {layer.type === "text" && <TextRotationControls ctx={ctx} />}

    <section className="fx-section">
      <h3 className="panel-subtitle">Transparency</h3>
      <Slider label="Opacity" value={Math.round((layer.opacity ?? 1) * 100)} min={0} max={100} unit="%" onChange={v => ctx.patch(layer.id, { opacity: v / 100 })} />
      <div className="fx-quick">{[100, 75, 50, 25].map(pct => <button key={pct} className={Math.round((layer.opacity ?? 1) * 100) === pct ? "active" : ""} onClick={() => ctx.patch(layer.id, { opacity: pct / 100 })}>{pct}%</button>)}</div>
    </section>

    {layer.type === "text" && <TextCurveControls ctx={ctx} />}
    {layer.type === "text" && <TextOutlineControls ctx={ctx} />}

    {hasEffects(fx) && <button className="secondary-button full-width" onClick={() => ctx.patch(layer.id, { effects: undefined })}><RotateCcw size={15} />Clear all effects</button>}
    <div className="editor-tip"><Wand2 size={19} /><p>Shadows, glows and outlines follow the element&apos;s shape — including cut-out photos and text.</p></div>
  </>;
}
