import { useEffect, useRef, useState } from "react";
import { Link2, Ruler, Unlink2 } from "lucide-react";
import type { DesignLayer } from "@/lib/designs";
import { formatSizeLabel, LENGTH_UNIT_LABELS, LENGTH_UNITS, useLengthUnit } from "@/lib/length-unit";
import { fromDisplayUnit, tableSize, toDisplayUnit, type LengthUnit } from "@/lib/table";
import { isCurvedText } from "@/lib/text-curve";
import { wrappedTextHeight } from "@/lib/text-fit";

interface Props {
  /** The selected element. The toolbar never edits the canvas — that lives in the top bar. */
  layer: DesignLayer | null;
  /** Applies a patch to the selected element. */
  onPatch: (updates: Partial<DesignLayer>) => void;
}

type Axis = "width" | "height";

const MIN_SIZE = 8;
const MAX_SIZE = 10000;
/** Padded so 156.6 always reads as "156.60" — the trailing digits never look raised or cut off. */
const format = (value: number, unit?: LengthUnit) => unit === "px" ? String(Math.round(value)) : value.toFixed(2);

/** Icons and QR codes are never stretched (the canvas only offers their corner handles); curved text scales as one piece. */
const alwaysKeepsProportions = (layer: DesignLayer) => layer.type === "icon" || (layer.type === "image" && !!layer.qr) || isCurvedText(layer);

/** Smallest size (px) an element may be given from the toolbar. */
function minimumSize(layer: DesignLayer, axis: Axis) {
  if (layer.type !== "table") return MIN_SIZE;
  const { rows, cols } = tableSize(layer);
  return (axis === "width" ? cols : rows) * MIN_SIZE;
}

/** Turns "make this element `pixels` wide/high" into a layer patch, following each element type's own resize rules. */
function resizePatch(layer: DesignLayer, axis: Axis, pixels: number, ratioLocked: boolean): Partial<DesignLayer> {
  if (layer.type === "text") {
    // Curved text is rescaled as a whole by the editor, so only the requested side is sent.
    if (isCurvedText(layer)) return { [axis]: pixels };
    if (layer.erased?.length) {
      if (ratioLocked) {
        const k = pixels / Math.max(1, layer[axis]);
        return { width: Math.round(layer.width * k), height: Math.round(layer.height * k), fontSize: Math.max(8, Math.min(1000, Math.round((layer.fontSize || 40) * k))) };
      }
      if (axis === "height") {
        const k = pixels / Math.max(1, layer.height);
        return { height: Math.round(pixels), fontSize: Math.max(8, Math.min(1000, Math.round((layer.fontSize || 40) * k))) };
      }
      return { width: Math.round(pixels) };
    }
    if (ratioLocked) {
      const k = pixels / layer[axis];
      return { width: layer.width * k, height: layer.height * k, fontSize: Math.max(8, Math.min(1000, (layer.fontSize || 40) * k)) };
    }
    // A new width re-wraps the words and the height follows; the box becomes a fixed frame.
    return axis === "width" ? { width: pixels, height: wrappedTextHeight(layer, pixels), autoFit: false } : { height: pixels };
  }
  if (ratioLocked || alwaysKeepsProportions(layer)) {
    const k = pixels / layer[axis];
    const patch: Partial<DesignLayer> = { width: layer.width * k, height: layer.height * k };
    if (layer.type === "stroke" && layer.strokeWidth) patch.strokeWidth = Math.max(1, Math.min(400, layer.strokeWidth * k));
    return patch;
  }
  const patch: Partial<DesignLayer> = { [axis]: pixels };
  // Like dragging a line's handle: thickness follows its height.
  if (layer.type === "stroke" && layer.strokeWidth && axis === "height") patch.strokeWidth = Math.max(1, Math.min(400, layer.strokeWidth * pixels / layer.height));
  return patch;
}

interface FieldProps { axis: "W" | "H"; label: string; value: number | null; min: number; max: number; step: number; disabled: boolean; unit: LengthUnit; onCommit: (value: number) => void }

/** Commits on blur / Enter, so clearing the field while typing never resizes the element to zero. */
function SizeField({ axis, label, value, min, max, step, disabled, unit, onCommit }: FieldProps) {
  const [draft, setDraft] = useState(value === null ? "" : format(value, unit));
  const focused = useRef(false);
  const cancelled = useRef(false);
  useEffect(() => { if (!focused.current) setDraft(value === null ? "" : format(value, unit)); }, [value, unit]);

  return <label className="size-field" title={disabled && value === null ? "Select an element to set its size" : `${label} (${LENGTH_UNIT_LABELS[unit]})`}>
    <span>{axis}</span>
    <input
      type="number"
      inputMode="decimal"
      min={min}
      max={max}
      step={step}
      disabled={disabled}
      placeholder="–"
      aria-label={label}
      value={draft}
      onFocus={() => { focused.current = true; cancelled.current = false; }}
      onChange={event => setDraft(event.target.value)}
      onBlur={() => {
        focused.current = false;
        const number = Number(draft);
        if (value === null || cancelled.current || !draft.trim() || !Number.isFinite(number)) { setDraft(value === null ? "" : format(value, unit)); return; }
        const next = Math.max(min, Math.min(max, number));
        onCommit(next);
        setDraft(format(next, unit));
      }}
      onKeyDown={event => {
        // Keep Delete / Backspace / arrows from reaching the canvas shortcuts.
        event.stopPropagation();
        if (event.key === "Enter") event.currentTarget.blur();
        if (event.key === "Escape") { cancelled.current = true; event.currentTarget.blur(); }
      }}
    />
  </label>;
}

/**
 * Width / height / proportion lock / unit (MM, Inch, Px — default MM) shown in the canvas toolbar.
 * These fields belong to the selected ELEMENT only — with nothing selected the toolbar shows a
 * hint instead, because the canvas size is edited from the top bar.
 */
export default function SizeFields({ layer, onPatch }: Props) {
  const [unit, setUnit] = useLengthUnit();
  const [ratioLocked, setRatioLocked] = useState(false);
  const forced = !!layer && alwaysKeepsProportions(layer);
  const locked = !!layer?.locked;
  const disabled = !layer || locked;
  const step = unit === "px" ? 1 : unit === "in" ? 0.05 : 0.5;

  if (!layer) {
    return <span className="size-fields-empty" data-keep-text-editing data-keep-cell-editing title="Canvas size lives in the top bar — click an element to set its width & height">
      <Ruler size={12} /> Select an element for W / H
    </span>;
  }

  function commit(axis: Axis, value: number) {
    if (!layer || locked) return;
    const pixels = Math.max(minimumSize(layer, axis), fromDisplayUnit(value, unit));
    onPatch(resizePatch(layer, axis, pixels, ratioLocked));
  }

  const field = (axis: Axis) => layer ? (
    <SizeField
      axis={axis === "width" ? "W" : "H"}
      label={`Element ${axis} (${LENGTH_UNIT_LABELS[unit]})`}
      value={toDisplayUnit(layer[axis], unit)}
      min={Number(toDisplayUnit(minimumSize(layer, axis), unit).toFixed(2))}
      max={Number(toDisplayUnit(MAX_SIZE, unit).toFixed(2))}
      step={step}
      disabled={disabled}
      unit={unit}
      onCommit={value => commit(axis, value)}
    />
  ) : null;

  const lockedRatio = ratioLocked || forced;
  const linkTitle = forced ? "This element always keeps its proportions"
    : lockedRatio ? "Proportions locked — click to unlock" : "Lock proportions";
  const readout = formatSizeLabel(layer.width, layer.height, unit);

  return <div className={`size-fields${locked ? " is-locked" : ""}`} title={readout} data-keep-text-editing data-keep-cell-editing role="group" aria-label="Element size">
    {field("width")}
    <button
      type="button"
      className={`size-link ${lockedRatio ? "active" : ""}`}
      aria-pressed={lockedRatio}
      aria-label={lockedRatio ? "Unlock proportions" : "Lock proportions"}
      title={linkTitle}
      disabled={disabled || forced}
      onPointerDown={event => event.preventDefault()}
      onClick={() => setRatioLocked(!ratioLocked)}
    >
      {lockedRatio ? <Link2 size={13} /> : <Unlink2 size={13} />}
    </button>
    {field("height")}
    <select className="size-unit" aria-label="Size measurement unit" title="Measurement unit (MM, Inch, Px)" value={unit} onChange={event => setUnit(event.target.value as LengthUnit)}>
      {LENGTH_UNITS.map(item => <option key={item} value={item}>{LENGTH_UNIT_LABELS[item]}</option>)}
    </select>
  </div>;
}
