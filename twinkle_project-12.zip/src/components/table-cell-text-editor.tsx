import { useEffect, useRef } from "react";
import type { DesignLayer } from "@/lib/designs";
import { layoutCellText } from "@/lib/table-text";
import { tableCellTextColor } from "@/lib/table";

interface Props {
  layer: DesignLayer; r: number; c: number; width: number; height: number; scale: number;
  onChange: (text: string) => void; onCommit: () => void; onStart: () => void; onEnd: () => void;
}

export default function TableCellTextEditor({ layer, r, c, width, height, scale, onChange, onCommit, onStart, onEnd }: Props) {
  const ref = useRef<HTMLTextAreaElement>(null);
  const callbacks = useRef({ onCommit, onStart, onEnd });
  callbacks.current = { onCommit, onStart, onEnd };
  const layout = layoutCellText(layer, r, c, width, height);
  useEffect(() => {
    ref.current?.focus({ preventScroll: true });
    ref.current?.select();
    function outside(event: PointerEvent) {
      const target = event.target as Element;
      if (!ref.current?.contains(target) && !target.closest('[data-keep-cell-editing]')) callbacks.current.onCommit();
    }
    document.addEventListener('pointerdown', outside, true);
    return () => document.removeEventListener('pointerdown', outside, true);
  }, [layer.id, r, c]);
  return <textarea ref={ref} className="table-cell-editor" aria-label={`Edit cell row ${r + 1} column ${c + 1}`} maxLength={160} spellCheck={false} value={layer.cells?.[(layer.cols || 1) * r + c] || ""}
    style={{ inset: 'auto', left: layout.padX * scale, top: layout.padY * scale, width: Math.max(1, width - layout.padX * 2) * scale, height: Math.max(1, height - layout.padY * 2) * scale, padding: 0, paddingTop: Math.max(0, layout.top - layout.padY) * scale, background: 'transparent', color: tableCellTextColor(layer, r, c), fontSize: layout.fontSize * scale, fontFamily: layout.fontFamily, fontWeight: layout.fontWeight, fontStyle: layout.italic ? 'italic' : 'normal', lineHeight: layout.lineHeight, letterSpacing: layout.letterSpacing * scale, textAlign: layout.align, textDecoration: [layout.underline ? 'underline' : '', layout.strikethrough ? 'line-through' : ''].filter(Boolean).join(' ') || 'none' }}
    onFocus={() => callbacks.current.onStart()} onBlur={() => callbacks.current.onEnd()}
    onPointerDown={event => event.stopPropagation()} onClick={event => event.stopPropagation()} onDoubleClick={event => event.stopPropagation()}
    onChange={event => onChange(event.target.value)} onKeyDown={event => { event.stopPropagation(); if (event.key === 'Escape' || (event.key === 'Enter' && !event.shiftKey)) { event.preventDefault(); callbacks.current.onCommit(); } }}
  />;
}
